# Inventory Management Server-Side Implementation Guide

## Overview
This document outlines the server-side implementation requirements for the comprehensive inventory management system with role-based permissions, restock approval workflow, and history/logs tracking.

## Database Schema

### 1. Inventory Items Table (existing - may need updates)
```sql
-- Table: dcms_inventory_items
CREATE TABLE IF NOT EXISTS dcms_inventory_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  item_name TEXT NOT NULL,
  category TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 0,
  unit TEXT NOT NULL,
  purchase_unit TEXT NOT NULL,
  conversion_factor INTEGER NOT NULL DEFAULT 1,
  min_threshold INTEGER NOT NULL DEFAULT 0,
  max_threshold INTEGER NOT NULL DEFAULT 0,
  last_restocked TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 2. Restock Requests Table (NEW)
```sql
-- Table: dcms_restock_requests
CREATE TABLE IF NOT EXISTS dcms_restock_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id UUID NOT NULL REFERENCES dcms_inventory_items(id) ON DELETE CASCADE,
  item_name TEXT NOT NULL,
  purchase_quantity INTEGER NOT NULL,
  usage_quantity INTEGER NOT NULL,
  notes TEXT,
  requested_by TEXT NOT NULL,
  requested_by_name TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  reviewed_by TEXT,
  reviewed_by_name TEXT,
  reviewed_at TIMESTAMPTZ,
  review_notes TEXT
);

CREATE INDEX idx_restock_requests_item_id ON dcms_restock_requests(item_id);
CREATE INDEX idx_restock_requests_status ON dcms_restock_requests(status);
CREATE INDEX idx_restock_requests_requested_by ON dcms_restock_requests(requested_by);
```

### 3. Inventory Logs Table (NEW)
```sql
-- Table: dcms_inventory_logs
CREATE TABLE IF NOT EXISTS dcms_inventory_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id UUID NOT NULL REFERENCES dcms_inventory_items(id) ON DELETE CASCADE,
  item_name TEXT NOT NULL,
  action TEXT NOT NULL CHECK (action IN ('add', 'edit', 'restock', 'restock_request', 'restock_approved', 'restock_rejected')),
  changed_by TEXT NOT NULL,
  changed_by_name TEXT,
  changes TEXT NOT NULL,
  timestamp TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_inventory_logs_item_id ON dcms_inventory_logs(item_id);
CREATE INDEX idx_inventory_logs_timestamp ON dcms_inventory_logs(timestamp DESC);
CREATE INDEX idx_inventory_logs_action ON dcms_inventory_logs(action);
```

## Server Endpoints

### 1. GET /inventory
**Purpose:** Fetch all inventory items with optional restock requests and logs

**Query Parameters:**
- `includeRequests` (boolean, default: true) - Include restock requests
- `includeLogs` (boolean, default: true) - Include inventory logs

**Response:**
```typescript
{
  items: InventoryItem[],
  restockRequests?: RestockRequest[],
  logs?: InventoryLog[]
}
```

**Implementation:**
```typescript
// Fetch inventory items
const items = await supabase
  .from('dcms_inventory_items')
  .select('*')
  .order('item_name');

// Optionally fetch restock requests
let restockRequests = [];
if (includeRequests) {
  const { data } = await supabase
    .from('dcms_restock_requests')
    .select('*')
    .order('created_at', { ascending: false });
  
  // Populate user names from dcms_users
  restockRequests = await Promise.all(data.map(async (req) => {
    const requestedByUser = await getUserInfo(req.requested_by);
    const reviewedByUser = req.reviewed_by ? await getUserInfo(req.reviewed_by) : null;
    
    return {
      ...req,
      requestedByName: requestedByUser ? `${requestedByUser.first_name} ${requestedByUser.last_name}` : req.requested_by,
      reviewedByName: reviewedByUser ? `${reviewedByUser.first_name} ${reviewedByUser.last_name}` : req.reviewed_by
    };
  }));
}

// Optionally fetch logs (limit to recent 100)
let logs = [];
if (includeLogs) {
  const { data } = await supabase
    .from('dcms_inventory_logs')
    .select('*')
    .order('timestamp', { ascending: false })
    .limit(100);
  
  // Populate user names
  logs = await Promise.all(data.map(async (log) => {
    const user = await getUserInfo(log.changed_by);
    return {
      ...log,
      changedByName: user ? `${user.first_name} ${user.last_name}` : log.changed_by
    };
  }));
}

return { items: items.data, restockRequests, logs };
```

### 2. POST /inventory
**Purpose:** Add a new inventory item

**Request Body:**
```typescript
{
  itemName: string,
  category: string,
  quantity: number, // in usage units
  unit: string,
  purchaseUnit: string,
  conversionFactor: number,
  minThreshold: number,
  maxThreshold: number,
  addedBy: string // email
}
```

**Implementation:**
```typescript
// Insert item
const { data: item } = await supabase
  .from('dcms_inventory_items')
  .insert({
    item_name: itemName,
    category,
    quantity,
    unit,
    purchase_unit: purchaseUnit,
    conversion_factor: conversionFactor,
    min_threshold: minThreshold,
    max_threshold: maxThreshold,
    last_restocked: new Date().toISOString()
  })
  .select()
  .single();

// Create log entry
const user = await getUserInfo(addedBy);
await supabase
  .from('dcms_inventory_logs')
  .insert({
    item_id: item.id,
    item_name: itemName,
    action: 'add',
    changed_by: addedBy,
    changed_by_name: user ? `${user.first_name} ${user.last_name}` : addedBy,
    changes: `Added ${itemName} with initial stock of ${quantity} ${unit} (${Math.ceil(quantity / conversionFactor)} ${purchaseUnit}s)`
  });

return { item };
```

### 3. PUT /inventory/:id
**Purpose:** Edit an existing inventory item

**Request Body:**
```typescript
{
  itemName: string,
  category: string,
  unit: string,
  purchaseUnit: string,
  conversionFactor: number,
  minThreshold: number,
  maxThreshold: number,
  updatedBy: string // email
}
```

**Implementation:**
```typescript
// Get old values for logging
const { data: oldItem } = await supabase
  .from('dcms_inventory_items')
  .select('*')
  .eq('id', itemId)
  .single();

// Update item
const { data: item } = await supabase
  .from('dcms_inventory_items')
  .update({
    item_name: itemName,
    category,
    unit,
    purchase_unit: purchaseUnit,
    conversion_factor: conversionFactor,
    min_threshold: minThreshold,
    max_threshold: maxThreshold,
    updated_at: new Date().toISOString()
  })
  .eq('id', itemId)
  .select()
  .single();

// Create detailed change log
const changes = [];
if (oldItem.item_name !== itemName) changes.push(`Name: ${oldItem.item_name} → ${itemName}`);
if (oldItem.category !== category) changes.push(`Category: ${oldItem.category} → ${category}`);
if (oldItem.min_threshold !== minThreshold) changes.push(`Min threshold: ${oldItem.min_threshold} → ${minThreshold}`);
if (oldItem.max_threshold !== maxThreshold) changes.push(`Max threshold: ${oldItem.max_threshold} → ${maxThreshold}`);

const user = await getUserInfo(updatedBy);
await supabase
  .from('dcms_inventory_logs')
  .insert({
    item_id: itemId,
    item_name: itemName,
    action: 'edit',
    changed_by: updatedBy,
    changed_by_name: user ? `${user.first_name} ${user.last_name}` : updatedBy,
    changes: changes.join(', ')
  });

return { item };
```

### 4. POST /inventory/:id/restock
**Purpose:** Restock an item (admin only - direct restock)

**Request Body:**
```typescript
{
  quantity: number, // in usage units
  purchaseQuantity: number,
  notes?: string,
  restockedBy: string // email
}
```

**Implementation:**
```typescript
// Get current item
const { data: item } = await supabase
  .from('dcms_inventory_items')
  .select('*')
  .eq('id', itemId)
  .single();

const newQuantity = item.quantity + quantity;

// Update quantity
const { data: updatedItem } = await supabase
  .from('dcms_inventory_items')
  .update({
    quantity: newQuantity,
    last_restocked: new Date().toISOString(),
    updated_at: new Date().toISOString()
  })
  .eq('id', itemId)
  .select()
  .single();

// Create log entry
const user = await getUserInfo(restockedBy);
await supabase
  .from('dcms_inventory_logs')
  .insert({
    item_id: itemId,
    item_name: item.item_name,
    action: 'restock',
    changed_by: restockedBy,
    changed_by_name: user ? `${user.first_name} ${user.last_name}` : restockedBy,
    changes: `Restocked ${purchaseQuantity} ${item.purchase_unit}s (${quantity} ${item.unit}). Previous: ${item.quantity}, New: ${newQuantity}${notes ? `. Notes: ${notes}` : ''}`
  });

return { item: updatedItem };
```

### 5. POST /inventory/restock-requests
**Purpose:** Create a restock request (staff only)

**Request Body:**
```typescript
{
  itemId: string,
  itemName: string,
  purchaseQuantity: number,
  usageQuantity: number,
  notes?: string,
  requestedBy: string // email
}
```

**Implementation:**
```typescript
// Create restock request
const user = await getUserInfo(requestedBy);
const { data: request } = await supabase
  .from('dcms_restock_requests')
  .insert({
    item_id: itemId,
    item_name: itemName,
    purchase_quantity: purchaseQuantity,
    usage_quantity: usageQuantity,
    notes,
    requested_by: requestedBy,
    requested_by_name: user ? `${user.first_name} ${user.last_name}` : requestedBy,
    status: 'pending'
  })
  .select()
  .single();

// Create log entry
await supabase
  .from('dcms_inventory_logs')
  .insert({
    item_id: itemId,
    item_name: itemName,
    action: 'restock_request',
    changed_by: requestedBy,
    changed_by_name: user ? `${user.first_name} ${user.last_name}` : requestedBy,
    changes: `Requested restock of ${purchaseQuantity} units (${usageQuantity} usage units)${notes ? `. Notes: ${notes}` : ''}`
  });

return { request };
```

### 6. PUT /inventory/restock-requests/:id
**Purpose:** Approve or reject a restock request (admin only)

**Request Body:**
```typescript
{
  action: 'approve' | 'reject',
  reviewedBy: string, // email
  reviewNotes?: string
}
```

**Implementation:**
```typescript
// Get the request
const { data: request } = await supabase
  .from('dcms_restock_requests')
  .select('*')
  .eq('id', requestId)
  .single();

if (!request || request.status !== 'pending') {
  throw new Error('Invalid or already processed request');
}

const user = await getUserInfo(reviewedBy);
const reviewerName = user ? `${user.first_name} ${user.last_name}` : reviewedBy;

if (action === 'approve') {
  // Update inventory quantity
  const { data: item } = await supabase
    .from('dcms_inventory_items')
    .select('*')
    .eq('id', request.item_id)
    .single();

  const newQuantity = item.quantity + request.usage_quantity;

  await supabase
    .from('dcms_inventory_items')
    .update({
      quantity: newQuantity,
      last_restocked: new Date().toISOString(),
      updated_at: new Date().toISOString()
    })
    .eq('id', request.item_id);

  // Create approval log
  await supabase
    .from('dcms_inventory_logs')
    .insert({
      item_id: request.item_id,
      item_name: request.item_name,
      action: 'restock_approved',
      changed_by: reviewedBy,
      changed_by_name: reviewerName,
      changes: `Approved restock request from ${request.requested_by_name}. Added ${request.purchase_quantity} units (${request.usage_quantity} usage units). Previous: ${item.quantity}, New: ${newQuantity}${reviewNotes ? `. Review notes: ${reviewNotes}` : ''}`
    });
} else if (action === 'reject') {
  // Create rejection log
  await supabase
    .from('dcms_inventory_logs')
    .insert({
      item_id: request.item_id,
      item_name: request.item_name,
      action: 'restock_rejected',
      changed_by: reviewedBy,
      changed_by_name: reviewerName,
      changes: `Rejected restock request from ${request.requested_by_name}. Requested: ${request.purchase_quantity} units${reviewNotes ? `. Reason: ${reviewNotes}` : ''}`
    });
}

// Update request status
const { data: updatedRequest } = await supabase
  .from('dcms_restock_requests')
  .update({
    status: action === 'approve' ? 'approved' : 'rejected',
    reviewed_by: reviewedBy,
    reviewed_by_name: reviewerName,
    reviewed_at: new Date().toISOString(),
    review_notes: reviewNotes
  })
  .eq('id', requestId)
  .select()
  .single();

return { request: updatedRequest };
```

## Helper Functions

### getUserInfo
```typescript
async function getUserInfo(email: string) {
  const { data: user } = await supabase
    .from('dcms_users')
    .select('first_name, last_name, role')
    .eq('email', email)
    .single();
  
  return user;
}
```

## Role-Based Access Control

### Permission Matrix
| Action | Staff | Dentist | Admin |
|--------|-------|---------|-------|
| View inventory cards | ✓ | ✓ | ✓ |
| View history/logs | ✓ | ✓ | ✓ |
| Add item | ✗ | ✗ | ✓ |
| Edit item | ✗ | ✗ | ✓ |
| Request restock | ✓ | ✗ | ✗ |
| Direct restock | ✗ | ✗ | ✓ |
| Approve restock | ✗ | ✗ | ✓ |

### Implementation in Server Routes
```typescript
// Check permissions before processing
function checkPermission(userRole: string, action: string): boolean {
  const permissions = {
    admin: ['view', 'add', 'edit', 'restock', 'approve'],
    staff: ['view', 'request_restock'],
    dentist: ['view']
  };
  
  return permissions[userRole]?.includes(action) || false;
}
```

## Testing Checklist

- [ ] Create inventory item (admin only)
- [ ] Edit inventory item (admin only)
- [ ] Staff creates restock request
- [ ] Admin approves restock request (inventory updates)
- [ ] Admin rejects restock request (no inventory change)
- [ ] Admin performs direct restock
- [ ] All actions create appropriate log entries
- [ ] User names are properly populated in requests and logs
- [ ] Permissions are enforced on all endpoints
- [ ] History/logs display correctly
- [ ] Pending requests show for admin
- [ ] Staff can only see their own pending requests (optional feature)

## Migration Steps

1. Create the two new tables (`dcms_restock_requests`, `dcms_inventory_logs`)
2. Add the new server endpoints
3. Test with different user roles
4. Verify all log entries are created correctly
5. Confirm user names are populated from dcms_users table

## Notes

- All timestamps should be in UTC
- User names should be concatenated as `first_name + " " + last_name`
- Logs should be limited to the most recent 100 entries for performance
- Consider adding pagination for logs if needed
- The `changes` field should be descriptive and human-readable

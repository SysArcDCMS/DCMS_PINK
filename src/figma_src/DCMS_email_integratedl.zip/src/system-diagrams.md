# Go-Goyagoy Dental Clinic Management System - System Diagrams

## 1. Functional Decomposition Diagram (FDD)

```
Go-Goyagoy DCMS
├── Authentication & Authorization
│   ├── User Login/Logout
│   ├── Role-based Access Control
│   ├── Email Validation
│   └── Password Management
├── Patient Management
│   ├── Patient Registration
│   ├── Patient Profile Management
│   ├── Walk-in Patient Registration
│   └── Patient Medical Records
├── Appointment Management
│   ├── Appointment Booking
│   ├── Appointment Scheduling
│   ├── Appointment Confirmation
│   ├── Appointment Completion
│   ├── Appointment Rescheduling
│   └── Appointment Reports
├── Dental Services
│   ├── Service Catalog Management
│   ├── Service Pricing Configuration
│   ├── Service-Inventory Mapping
│   └── Service Suggestions
├── Tooth Chart System
│   ├── Interactive Tooth Chart Display
│   ├── Treatment History Tracking
│   ├── FDI Notation System
│   └── Multi-treatment Per Tooth Support
├── Billing Management
│   ├── Bill Generation
│   ├── Pricing Model Calculation
│   ├── Payment Processing
│   ├── Billing History
│   └── Financial Reports
├── Inventory Management
│   ├── Inventory Tracking
│   ├── Stock Management
│   ├── Restock Requests
│   └── Inventory Reports
├── User Management
│   ├── Staff Account Creation
│   ├── Dentist Account Management
│   ├── User Role Assignment
│   └── Access Control
├── Reporting & Analytics
│   ├── Appointment Reports
│   ├── Financial Reports
│   ├── Patient Statistics
│   └── Inventory Reports
└── System Administration
    ├── System Configuration
    ├── Data Backup
    ├── Server Management
    └── Audit Logging
```

## 2. Data Flow Diagram (DFD)

### Level 0 (Context Diagram)
```
┌─────────────────┐    ┌─────────────────────────────────┐    ┌─────────────────┐
│  Anonymous      │    │                                 │    │  External       │
│  Patient        ├────┤                                 ├────┤  Payment        │
│                 │    │                                 │    │  Gateway        │
└─────────────────┘    │                                 │    └─────────────────┘
                       │                                 │
┌─────────────────┐    │        Go-Goyagoy DCMS         │    ┌─────────────────┐
│  Registered     ├────┤                                 ├────┤  Email          │
│  Patient        │    │                                 │    │  Service        │
│                 │    │                                 │    │                 │
└─────────────────┘    │                                 │    └─────────────────┘
                       │                                 │
┌─────────────────┐    │                                 │    ┌─────────────────┐
│  Staff          ├────┤                                 ├────┤  Supabase       │
│                 │    │                                 │    │  Database       │
│                 │    │                                 │    │                 │
└─────────────────┘    └─────────────────────────────────┘    └─────────────────┘
                       
┌─────────────────┐                                           ┌─────────────────┐
│  Dentist/Admin  ├───────────────────────────────────────────┤  File Storage   │
│                 │                                           │  System         │
└─────────────────┘                                           └─────────────────┘
```

### Level 1 DFD
```
                    ┌─────────────────┐
                    │   User Login    │◄───── Login Credentials
                    │   Authentication│
                    │                 │
                    └─────────┬───────┘
                              │ User Session
                              ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│  Appointment    │    │   Authorization │    │  Patient        │
│  Booking        │◄───┤   & Access      ├───►│  Management     │
│  System         │    │   Control       │    │  System         │
└─────────┬───────┘    └─────────────────┘    └─────────┬───────┘
          │                                             │
          │ Appointment Data                            │ Patient Data
          ▼                                             ▼
┌─────────────────┐                                ┌─────────────────┐
│  Appointment    │                                │  Patient        │
│  Database       │                                │  Database       │
└─────────┬───────┘                                └─────────┬───────┘
          │                                                 │
          │ Service Info                                    │ Medical Records
          ▼                                                 ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│  Service        │    │  Billing        │    │  Tooth Chart    │
│  Management     ├───►│  System         │    │  System         │
│  System         │    │                 │    │                 │
└─────────┬───────┘    └─────────┬───────┘    └─────────┬───────┘
          │                      │                      │
          │ Inventory Usage      │ Payment Data         │ Treatment Data
          ▼                      ▼                      ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│  Inventory      │    │  Payment        │    │  Treatment      │
│  Management     │    │  Database       │    │  History        │
│  System         │    │                 │    │  Database       │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## 3. Use Case Diagram

```
                    Go-Goyagoy Dental Clinic Management System
                    
    Anonymous Patient           Registered Patient              Staff                    Dentist/Admin
         │                           │                          │                           │
         │                           │                          │                           │
    ┌────▼────┐                 ┌────▼────┐                ┌────▼────┐                 ┌────▼────┐
    │Book     │                 │Book     │                │Manage   │                 │Manage   │
    │Appoint. │                 │Appoint. │                │Appoint. │                 │Users    │
    └─────────┘                 └─────────┘                └─────────┘                 └─────────┘
         │                           │                          │                           │
         │                      ┌────▼────┐                ┌────▼────┐                 ┌────▼────┐
         │                      │Manage   │                │Confirm  │                 │View     │
         │                      │Profile  │                │Appoint. │                 │Reports  │
         │                      └─────────┘                └─────────┘                 └─────────┘
         │                           │                          │                           │
         │                      ┌────▼────┐                ┌────▼────┐                 ┌────▼────┐
         │                      │View     │                │Walk-in  │                 │Manage   │
         │                      │History  │                │Patient  │                 │Services │
         │                      └─────────┘                └─────────┘                 └─────────┘
         │                           │                          │                           │
         │                      ┌────▼────┐                ┌────▼────┐                 ┌────▼────┐
         │                      │View     │                │Complete │                 │Manage   │
         │                      │Billing  │                │Appoint. │                 │Inventory│
         │                      └─────────┘                └─────────┘                 └─────────┘
         │                           │                          │                           │
         │                           │                     ┌────▼────┐                 ┌────▼────┐
         │                           │                     │Generate │                 │View Tooth│
         │                           │                     │Bill     │                 │Charts   │
         │                           │                     └─────────┘                 └─────────┘
         │                           │                          │                           │
         │                           │                     ┌────▼────┐                      │
         │                           │                     │Manage   │                      │
         │                           │                     │Inventory│                      │
         │                           │                     └─────────┘                      │
         │                           │                          │                           │
         └───────────────────────────┼──────────────────────────┼───────────────────────────┘
                                     │                          │
                                ┌────▼────┐                ┌────▼────┐
                                │View     │                │Add      │
                                │Tooth    │                │Treatment│
                                │Chart    │                │Notes    │
                                └─────────┘                └─────────┘

    System Boundaries:
    ─────────────────────────────────────────────────────────────────
    │                          <<extends>>                          │
    │  Email Validation    Password Reset    Payment Processing     │
    │  Notification System    Audit Logging    Data Backup         │
    └───────────────────────────────────────────────────────────────┘
```

## 4. Entity Relationship Diagram (ERD)

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│     USERS       │    │   PATIENTS      │    │  APPOINTMENTS   │
├─────────────────┤    ├─────────────────┤    ├─────────────────┤
│ id (PK)         │    │ id (PK)         │    │ id (PK)         │
│ email           │    │ user_id (FK)    │    │ patient_id (FK) │
│ first_name      │    │ phone           │    │ dentist_id (FK) │
│ last_name       │    │ address         │    │ service_id (FK) │
│ role            │    │ date_of_birth   │    │ appointment_date│
│ password_hash   │    │ emergency_cont. │    │ start_time      │
│ email_validated │    │ medical_hist.   │    │ end_time        │
│ created_at      │    │ created_at      │    │ status          │
│ updated_at      │    │ updated_at      │    │ notes           │
└─────────────────┘    └─────────────────┘    │ tooth_numbers   │
         │                       │             │ created_at      │
         │ 1:1                   │ 1:M         │ updated_at      │
         └───────────────────────┘             └─────────────────┘
                                                        │
         ┌─────────────────┐                           │ M:1
         │    SERVICES     │                           │
         ├─────────────────┤                           │
         │ id (PK)         │ 1:M                       │
         │ name            │──────────────────────────┘
         │ description     │
         │ base_price      │    ┌─────────────────┐
         │ pricing_model   │    │    BILLING      │
         │ tooth_chart_use │    ├─────────────────┤
         │ duration        │    │ id (PK)         │
         │ created_at      │    │ appointment_id  │ 1:1
         │ updated_at      │    │ amount          │─────┐
         └─────────────────┘    │ tax_amount      │     │
                                │ total_amount    │     │
         ┌─────────────────┐    │ payment_status  │     │
         │   INVENTORY     │    │ payment_method  │     │
         ├─────────────────┤    │ paid_date       │     │
         │ id (PK)         │    │ created_at      │     │
         │ name            │    │ updated_at      │     │
         │ description     │    └─────────────────┘     │
         │ current_stock   │                            │
         │ min_stock       │    ┌─────────────────┐     │
         │ max_stock       │    │ TOOTH_CHARTS    │     │
         │ unit_cost       │    ├─────────────────┤     │
         │ supplier        │    │ id (PK)         │     │
         │ created_at      │    │ patient_id (FK) │ 1:1 │
         │ updated_at      │    │ chart_data      │─────┘
         └─────────────────┘    │ last_updated    │
                  │             │ created_at      │
                  │ M:M         └─────────────────┘
                  │
         ┌─────────────────┐    ┌─────────────────┐
         │SERVICE_INVENTORY│    │MEDICAL_RECORDS  │
         ├─────────────────┤    ├─────────────────┤
         │ service_id (FK) │    │ id (PK)         │
         │ inventory_id(FK)│    │ patient_id (FK) │ 1:M
         │ quantity_used   │    │ record_type     │─────┐
         │ created_at      │    │ record_data     │     │
         └─────────────────┘    │ file_url        │     │
                                │ created_by (FK) │     │
         ┌─────────────────┐    │ created_at      │     │
         │RESTOCK_REQUESTS │    └─────────────────┘     │
         ├─────────────────┤                            │
         │ id (PK)         │    ┌─────────────────┐     │
         │ inventory_id(FK)│    │  NOTIFICATIONS  │     │
         │ requested_qty   │    ├─────────────────┤     │
         │ status          │    │ id (PK)         │     │
         │ requested_by(FK)│    │ user_id (FK)    │ 1:M │
         │ approved_by(FK) │    │ title           │─────┘
         │ created_at      │    │ message         │
         │ updated_at      │    │ type            │
         └─────────────────┘    │ read_status     │
                                │ created_at      │
                                └─────────────────┘
```

## 5. UML Class Diagram

```
┌─────────────────────────────────┐
│            User                 │
├─────────────────────────────────┤
│ - id: string                    │
│ - email: string                 │
│ - firstName: string             │
│ - lastName: string              │
│ - role: UserRole               │
│ - passwordHash: string          │
│ - emailValidated: boolean       │
│ - createdAt: Date              │
├─────────────────────────────────┤
│ + login(email, password): bool  │
│ + logout(): void               │
│ + validateEmail(): boolean      │
│ + resetPassword(): void        │
│ + getFullName(): string        │
└─────────────────────────────────┘
                │
                │ inherits
                ▼
┌─────────────────────────────────┐      ┌─────────────────────────────────┐
│           Patient               │      │         Appointment             │
├─────────────────────────────────┤      ├─────────────────────────────────┤
│ - phone: string                 │      │ - id: string                    │
│ - address: string               │      │ - patientId: string             │
│ - dateOfBirth: Date            │      │ - dentistId: string             │
│ - emergencyContact: string      │      │ - serviceId: string             │
│ - medicalHistory: string        │      │ - appointmentDate: Date         │
├─────────────────────────────────┤      │ - startTime: string             │
│ + bookAppointment(): boolean    │ 1  * │ - endTime: string               │
│ + updateProfile(): void         │──────│ - status: AppointmentStatus     │
│ + getToothChart(): ToothChart   │      │ - notes: string                 │
│ + getBillingHistory(): Bill[]   │      │ - toothNumbers: number[]        │
└─────────────────────────────────┘      ├─────────────────────────────────┤
                                         │ + confirm(): void               │
┌─────────────────────────────────┐      │ + complete(): void              │ *
│            Staff                │      │ + reschedule(newDate): boolean  │──┐
├─────────────────────────────────┤      │ + cancel(): void                │  │
│ - department: string            │      │ + addNotes(note): void          │  │
│ - specialization: string        │      └─────────────────────────────────┘  │
├─────────────────────────────────┤                                         │
│ + manageAppointments(): void    │      ┌─────────────────────────────────┐  │
│ + registerWalkIn(): Patient     │      │           Service               │  │ 1
│ + generateBill(): Bill          │      ├─────────────────────────────────┤  │
└─────────────────────────────────┘      │ - id: string                    │◄─┘
                                         │ - name: string                  │
┌─────────────────────────────────┐      │ - description: string           │
│          Dentist                │      │ - basePrice: decimal            │
├─────────────────────────────────┤      │ - pricingModel: PricingModel    │
│ - licenseNumber: string         │      │ - toothChartUse: ChartUse       │
│ - specialization: string        │      │ - duration: number              │
├─────────────────────────────────┤      ├─────────────────────────────────┤
│ + diagnosePatient(): void       │      │ + calculatePrice(teeth): decimal│
│ + createTreatmentPlan(): void   │      │ + updateInventory(): void       │
│ + updateToothChart(): void      │      └─────────────────────────────────┘
└─────────────────────────────────┘                        │
                                                           │ *
┌─────────────────────────────────┐      ┌─────────────────────────────────┐
│           Admin                 │      │          Inventory              │
├─────────────────────────────────┤      ├─────────────────────────────────┤
│ - permissions: string[]         │      │ - id: string                    │
├─────────────────────────────────┤      │ - name: string                  │
│ + createUser(): User            │   *  │ - currentStock: number          │
│ + manageUsers(): void           │──────│ - minStock: number              │
│ + generateReports(): Report[]   │      │ - maxStock: number              │
│ + configureSystem(): void       │      │ - unitCost: decimal             │
└─────────────────────────────────┘      ├─────────────────────────────────┤
                                         │ + checkStock(): boolean         │
┌─────────────────────────────────┐      │ + restock(quantity): void       │
│          ToothChart             │      │ + updateUsage(qty): void        │
├─────────────────────────────────┤      └─────────────────────────────────┘
│ - patientId: string             │
│ - chartData: ToothData[]        │      ┌─────────────────────────────────┐
│ - lastUpdated: Date            │      │            Bill                 │
├─────────────────────────────────┤      ├─────────────────────────────────┤
│ + updateTooth(num, data): void  │      │ - id: string                    │
│ + getTreatmentHistory(): void   │   1  │ - appointmentId: string         │
│ + addTreatment(): void          │──────│ - amount: decimal               │
└─────────────────────────────────┘    * │ - taxAmount: decimal            │
                                         │ - totalAmount: decimal          │
                                         │ - paymentStatus: PaymentStatus  │
                                         ├─────────────────────────────────┤
                                         │ + generateInvoice(): string     │
                                         │ + processPayment(): boolean     │
                                         │ + sendReceipt(): void           │
                                         └─────────────────────────────────┘
```

## 6. Sequence Diagram - Appointment Booking Process

```
Patient    BookingForm    AppointmentAPI    Database    EmailService    NotificationService
   │            │              │             │              │                    │
   │  Submit    │              │             │              │                    │
   │  Booking   │              │             │              │                    │
   │───────────►│              │             │              │                    │
   │            │ Validate     │             │              │                    │
   │            │ Form Data    │             │              │                    │
   │            │──────────────│             │              │                    │
   │            │              │ Check       │              │                    │
   │            │              │ Availability│              │                    │
   │            │              │────────────►│              │                    │
   │            │              │             │ Return Slots │                    │
   │            │              │◄────────────│              │                    │
   │            │              │ Create      │              │                    │
   │            │              │ Appointment │              │                    │
   │            │              │────────────►│              │                    │
   │            │              │             │ Save Data    │                    │
   │            │              │             │──────────────│                    │
   │            │              │             │ Return ID    │                    │
   │            │              │◄────────────│              │                    │
   │            │              │ Send        │              │                    │
   │            │              │ Confirmation│              │                    │
   │            │              │─────────────┼─────────────►│                    │
   │            │              │             │              │ Email Sent         │
   │            │              │             │              │◄───────────────────│
   │            │              │ Create      │              │                    │
   │            │              │ Notification│              │                    │
   │            │              │─────────────┼──────────────┼───────────────────►│
   │            │              │             │              │                    │ Notify Staff
   │            │              │             │              │                    │─────────────
   │            │ Return       │             │              │                    │
   │            │ Success      │             │              │                    │
   │◄───────────│              │             │              │                    │
   │ Show       │              │             │              │                    │
   │ Confirmation│             │              │                    │
   │────────────│              │             │              │                    │
```

## 7. Activity Diagram - Appointment Completion Workflow

```
                        [Appointment Scheduled]
                                 │
                                 ▼
                        ┌─────────────────┐
                        │ Staff Opens     │
                        │ Appointment     │
                        └─────────┬───────┘
                                 │
                                 ▼
                        ┌─────────────────┐    No   ┌─────────────────┐
                        │ Patient Arrived?├─────────► Return to       │
                        │                 │         │ Dashboard       │
                        └─────────┬───────┘         └─────────────────┘
                                 │ Yes
                                 ▼
                        ┌─────────────────┐
                        │ Start Treatment │
                        │ Process         │
                        └─────────┬───────┘
                                 │
                                 ▼
                        ┌─────────────────┐
                        │ Add Treatment   │
                        │ Notes           │
                        └─────────┬───────┘
                                 │
                                 ▼
                     ┌─────────────────┐    No    ┌─────────────────┐
                     │ Tooth Chart     ├──────────► Continue       │
                     │ Required?       │          │ Without Chart  │
                     └─────────┬───────┘          └─────────┬───────┘
                              │ Yes                        │
                              ▼                            │
                     ┌─────────────────┐                   │
                     │ Update Tooth    │                   │
                     │ Chart with      │                   │
                     │ Treatment Data  │                   │
                     └─────────┬───────┘                   │
                              │                            │
                              └────────────┬───────────────┘
                                          │
                                          ▼
                              ┌─────────────────┐
                              │ Mark Appointment│
                              │ as Completed    │
                              └─────────┬───────┘
                                       │
                                       ▼
                              ┌─────────────────┐
                              │ Update Inventory│
                              │ Based on Service│
                              │ Mappings        │
                              └─────────┬───────┘
                                       │
                                       ▼
                              ┌─────────────────┐
                              │ Generate Bill   │
                              │ Based on        │
                              │ Pricing Model   │
                              └─────────┬───────┘
                                       │
                                       ▼
                              ┌─────────────────┐
                              │ Send Completion │
                              │ Notification    │
                              │ to Patient      │
                              └─────────┬───────┘
                                       │
                                       ▼
                              ┌─────────────────┐
                              │ Update Patient  │
                              │ Treatment       │
                              │ History         │
                              └─────────┬───────┘
                                       │
                                       ▼
                                [Appointment Completed]
```

## 8. State Diagram - Appointment Lifecycle

```
                              [Initial State]
                                     │
                                     ▼
                            ┌─────────────────┐
                            │   SCHEDULED     │◄─────────────────┐
                            └─────────┬───────┘                  │
                                     │ patient_arrives /         │
                                     │ staff_confirms            │ reschedule /
                                     ▼                           │ update_datetime
                            ┌─────────────────┐                  │
                            │   CONFIRMED     ├──────────────────┘
                            └─────────┬───────┘
                                     │ start_treatment /
                                     │ staff_begins
                                     ▼
                            ┌─────────────────┐
                            │  IN_PROGRESS    │
                            └─────────┬───────┘
                                     │ complete_treatment /
                                     │ add_notes, update_chart
                                     ▼
                            ┌─────────────────┐
                            │   COMPLETED     │
                            └─────────┬───────┘
                                     │ generate_bill /
                                     │ calculate_pricing
                                     ▼
                            ┌─────────────────┐
                            │     BILLED      │
                            └─────────┬───────┘
                                     │ process_payment /
                                     │ update_billing_status
                                     ▼
                            ┌─────────────────┐
                            │      PAID       │
                            └─────────────────┘

                    Cancel Transitions (from any state):
                    ═══════════════════════════════════════
                              cancel / notify_patient
                                     │
                                     ▼
                            ┌─────────────────┐
                            │   CANCELLED     │
                            └─────────────────┘

                    No-Show Transitions:
                    ═══════════════════════
                    CONFIRMED ──no_show / mark_no_show──► NO_SHOW
```

## 9. Context Diagram (Level 0 DFD)

```
                                External Systems
                            ┌─────────────────────────┐
                            │                         │
                            │  ┌─────────────────┐    │
                            │  │ Email Service   │    │
                            │  │ (SMTP)          │    │
                            │  └─────────────────┘    │
                            │                         │
                            │  ┌─────────────────┐    │
                            │  │ Payment Gateway │    │
                            │  │ (Stripe/PayPal) │    │
                            │  └─────────────────┘    │
                            │                         │
                            │  ┌─────────────────┐    │
                            │  │ SMS Service     │    │
                            │  │ (Twilio)        │    │
                            │  └─────────────────┘    │
                            └─────────────────────────┘
                                         ▲
                                         │ API calls
                                         │ notifications
                                         │ payments
                                         ▼
    ┌──────────────┐    ┌─────────────────────────────────────┐    ┌──────────────┐
    │              │    │                                     │    │              │
    │  Anonymous   │    │                                     │    │   Supabase   │
    │  Patients    ├───►│        Go-Goyagoy DCMS             │◄───┤   Database   │
    │              │    │                                     │    │              │
    └──────────────┘    │  ┌─────────────────────────────┐    │    └──────────────┘
                        │  │                             │    │
    ┌──────────────┐    │  │       Next.js Frontend      │    │    ┌──────────────┐
    │              │    │  │                             │    │    │              │
    │ Registered   ├───►│  └─────────────────────────────┘    │◄───┤ File Storage │
    │ Patients     │    │                                     │    │ (Supabase)   │
    │              │    │  ┌─────────────────────────────┐    │    │              │
    └──────────────┘    │  │                             │    │    └──────────────┘
                        │  │    Supabase Edge Functions  │    │
    ┌──────────────┐    │  │                             │    │    ┌──────────────┐
    │              │    │  └─────────────────────────────┘    │    │              │
    │    Staff     ├───►│                                     │◄───┤ KV Store     │
    │              │    │  ┌─────────────────────────────┐    │    │ (Tooth       │
    │              │    │  │                             │    │    │  Charts)     │
    └──────────────┘    │  │      API Routes Layer       │    │    │              │
                        │  │                             │    │    └──────────────┘
    ┌──────────────┐    │  └─────────────────────────────┘    │
    │              │    │                                     │
    │ Dentist/     ├───►│                                     │
    │ Admin        │    └─────────────────────────────────────┘
    │              │
    └──────────────┘            Data flows:
                               ─────────────
                               • User credentials
                               • Appointment requests
                               • Patient data
                               • Treatment records
                               • Billing information
                               • Inventory updates
                               • Reports and analytics
```

## 10. Architecture Diagram

```
                               Client Layer
                    ┌─────────────────────────────────┐
                    │                                 │
                    │         Web Browser             │
                    │    (React/Next.js App)          │
                    │                                 │
                    └─────────────┬───────────────────┘
                                  │ HTTPS/WebSocket
                                  │ API Calls
                                  ▼
                               Presentation Layer
                    ┌─────────────────────────────────┐
                    │                                 │
                    │       Next.js Frontend          │
                    │  ┌─────────────────────────┐    │
                    │  │     React Components    │    │
                    │  │  ┌─────────────────┐    │    │
                    │  │  │ Authentication  │    │    │
                    │  │  │ Dashboard       │    │    │
                    │  │  │ Appointments    │    │    │
                    │  │  │ Patients        │    │    │
                    │  │  │ Billing         │    │    │
                    │  │  │ Tooth Chart     │    │    │
                    │  │  │ Inventory       │    │    │
                    │  │  └─────────────────┘    │    │
                    │  └─────────────────────────┘    │
                    │                                 │
                    │  ┌─────────────────────────┐    │
                    │  │    State Management     │    │
                    │  │  ┌─────────────────┐    │    │
                    │  │  │ React Context   │    │    │
                    │  │  │ SWR Cache       │    │    │
                    │  │  │ Local Storage   │    │    │
                    │  │  └─────────────────┘    │    │
                    │  └─────────────────────────┘    │
                    └─────────────┬───────────────────┘
                                  │ API Routes
                                  │ Server Actions
                                  ▼
                              Business Logic Layer
                    ┌─────────────────────────────────┐
                    │                                 │
                    │        Next.js API Routes       │
                    │  ┌─────────────────────────┐    │
                    │  │    Route Handlers       │    │
                    │  │  ┌─────────────────┐    │    │
                    │  │  │ /api/auth/*     │    │    │
                    │  │  │ /api/patients/* │    │    │
                    │  │  │ /api/appts/*    │    │    │
                    │  │  │ /api/billing/*  │    │    │
                    │  │  │ /api/inventory/*│    │    │
                    │  │  │ /api/services/* │    │    │
                    │  │  └─────────────────┘    │    │
                    │  └─────────────────────────┘    │
                    │                                 │
                    │  ┌─────────────────────────┐    │
                    │  │   Business Services     │    │
                    │  │  ┌─────────────────┐    │    │
                    │  │  │ AuthService     │    │    │
                    │  │  │ AppointmentSvc  │    │    │
                    │  │  │ PatientService  │    │    │
                    │  │  │ BillingService  │    │    │
                    │  │  │ InventoryService│    │    │
                    │  │  │ ToothChartSvc   │    │    │
                    │  │  └─────────────────┘    │    │
                    │  └─────────────────────────┘    │
                    └─────────────┬───────────────────┘
                                  │ Database Queries
                                  │ Edge Functions
                                  ▼
                              Data Access Layer
                    ┌─────────────────────────────────┐
                    │                                 │
                    │       Supabase Platform         │
                    │  ┌─────────────────────────┐    │
                    │  │     PostgreSQL DB       │    │
                    │  │  ┌─────────────────┐    │    │
                    │  │  │ Users Table     │    │    │
                    │  │  │ Patients Table  │    │    │
                    │  │  │ Appts Table     │    │    │
                    │  │  │ Services Table  │    │    │
                    │  │  │ Billing Table   │    │    │
                    │  │  │ Inventory Table │    │    │
                    │  │  │ Medical Records │    │    │
                    │  │  └─────────────────┘    │    │
                    │  └─────────────────────────┘    │
                    │                                 │
                    │  ┌─────────────────────────┐    │
                    │  │    Edge Functions       │    │
                    │  │  ┌─────────────────┐    │    │
                    │  │  │ Server Function │    │    │
                    │  │  │ KV Store Mgmt   │    │    │
                    │  │  │ Real-time Sync  │    │    │
                    │  │  └─────────────────┘    │    │
                    │  └─────────────────────────┘    │
                    │                                 │
                    │  ┌─────────────────────────┐    │
                    │  │      Storage            │    │
                    │  │  ┌─────────────────┐    │    │
                    │  │  │ File Storage    │    │    │
                    │  │  │ KV Store        │    │    │
                    │  │  │ (Tooth Charts)  │    │    │
                    │  │  └─────────────────┘    │    │
                    │  └─────────────────────────┘    │
                    └─────────────┬───────────────────┘
                                  │ External APIs
                                  ▼
                              External Services Layer
                    ┌─────────────────────────────────┐
                    │                                 │
                    │      Third-party Services       │
                    │  ┌─────────────────────────┐    │
                    │  │                         │    │
                    │  │  ┌─────────────────┐    │    │
                    │  │  │ Email Service   │    │    │
                    │  │  │ (SMTP/SendGrid) │    │    │
                    │  │  └─────────────────┘    │    │
                    │  │                         │    │
                    │  │  ┌─────────────────┐    │    │
                    │  │  │ Payment Gateway │    │    │
                    │  │  │ (Stripe)        │    │    │
                    │  │  └─────────────────┘    │    │
                    │  │                         │    │
                    │  │  ┌─────────────────┐    │    │
                    │  │  │ SMS Service     │    │    │
                    │  │  │ (Twilio)        │    │    │
                    │  │  └─────────────────┘    │    │
                    │  │                         │    │
                    │  └─────────────────────────┘    │
                    └─────────────────────────────────┘

                             Deployment Architecture
                    ┌─────────────────────────────────┐
                    │                                 │
                    │          Vercel Platform        │
                    │  ┌─────────────────────────┐    │
                    │  │     CDN/Edge Network    │    │
                    │  │   (Global Distribution) │    │
                    │  └─────────────────────────┘    │
                    │                                 │
                    │  ┌─────────────────────────┐    │
                    │  │    Next.js Runtime      │    │
                    │  │   (Serverless Functions)│    │
                    │  └─────────────────────────┘    │
                    └─────────────────────────────────┘
```

## Summary

These diagrams provide a comprehensive view of the Go-Goyagoy dental clinic management system, showing:

1. **Functional breakdown** of all system capabilities
2. **Data flow** between components and external systems
3. **User interactions** and system use cases
4. **Database structure** and relationships
5. **Object-oriented design** with clear inheritance and associations
6. **Process flows** for critical operations
7. **State management** for appointment lifecycle
8. **System context** and external dependencies
9. **Technical architecture** with clear separation of concerns

The system demonstrates a well-architected solution using modern web technologies (Next.js, Supabase) with comprehensive role-based access control, real-time updates, and integration with external services for payments and notifications.
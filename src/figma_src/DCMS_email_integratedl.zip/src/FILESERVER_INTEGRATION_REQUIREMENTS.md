# FileServer Integration Requirements

## Summary of Changes Made
1. **Fixed syntax error** in `/app/dashboard/patients/[id]/page.tsx` - removed escaped quotes in Download button
2. **Updated file API endpoints** to point to your FileServer at `http://localhost:9000`
3. **Created API specification** for seamless integration
4. **Ensured proper TypeScript typing** for all API responses

## Files Updated/Affected
- `/app/api/files/route.ts` - Updated to use localhost:9000 FileServer
- `/app/api/files/[id]/route.ts` - Updated download/delete endpoints
- `/app/dashboard/patients/[id]/page.tsx` - Fixed syntax error, restored Documents tab functionality
- `/fileserver-api-specification.md` - Created API contract specification

## FileServer API Response Requirements

### 1. Upload File Response (POST /api/files)
```json
{
  "file": {
    "id": "file_1234567890_abc123",
    "recordId": "medical_info_1234567890_def456", 
    "recordType": "medical_info",
    "patientId": "patient_123",
    "patientEmail": "patient@example.com",
    "fileName": "file_1234567890_abc123_document.pdf",
    "originalFileName": "document.pdf",
    "fileSize": 1024000,
    "fileType": "application/pdf",
    "uploadedBy": "staff_456",
    "uploadedByName": "Dr. Smith",
    "uploadedAt": "2024-01-15T10:30:00.000Z",
    "description": "Medical test results",
    "isActive": true
  }
}
```

### 2. Get Files Response (GET /api/files)
```json
{
  "files": [
    {
      "id": "file_1234567890_abc123",
      "recordId": "medical_info_1234567890_def456",
      "recordType": "medical_info",
      "patientId": "patient_123",
      "patientEmail": "patient@example.com",
      "fileName": "file_1234567890_abc123_document.pdf",
      "originalFileName": "document.pdf",
      "fileSize": 1024000,
      "fileType": "application/pdf",
      "uploadedBy": "staff_456",
      "uploadedByName": "Dr. Smith",
      "uploadedAt": "2024-01-15T10:30:00.000Z",
      "description": "Medical test results",
      "isActive": true
    }
  ]
}
```

## Key Integration Points

### Frontend API Proxy Routes
- **Upload**: `POST /api/files` → forwards to `http://localhost:9000/api/files`
- **List**: `GET /api/files?recordId=xxx` → forwards to `http://localhost:9000/api/files?recordId=xxx`
- **Download**: `GET /api/files/{id}` → forwards to `http://localhost:9000/api/files/{id}`
- **Delete**: `DELETE /api/files/{id}` → forwards to `http://localhost:9000/api/files/{id}`

### Environment Variables
Add to your `.env.local`:
```
FILE_SERVER_URL=http://localhost:9000
```

### Documents Display Logic
The Documents tab on PatientDetailsPage:
1. Collects files from all medical records (`medicalInfo`, `allergies`, `medications`)
2. Groups files by `recordType` 
3. Displays in organized sections with download buttons
4. Shows file metadata (size, upload date, uploader name)

## Testing the Integration

### 1. Upload Test
- Navigate to patient details page
- Go to Medical Info/Allergies/Medications tab
- Add a new record with file attachments
- Verify files appear in Documents tab

### 2. Display Test  
- Check Documents tab shows all uploaded files
- Verify proper grouping by record type
- Confirm file metadata displays correctly

### 3. Download Test
- Click Download button in Documents tab
- Verify file downloads with correct filename
- Check API call goes to `/api/files/{id}`

## Common Issues & Solutions

### Issue: Documents not showing
**Solution**: Ensure your FileServer returns `files` array in the exact structure above

### Issue: Download not working
**Solution**: Verify your FileServer handles file streaming properly for GET `/api/files/{id}`

### Issue: Upload failing
**Solution**: Check FileServer accepts multipart/form-data and returns the file object structure

## Next Steps
1. Ensure your FileServer at localhost:9000 matches the API specification
2. Test file upload functionality 
3. Verify documents display correctly in the Documents tab
4. Test file downloads work properly

The syntax error has been fixed and the Documents tab should now display uploaded files correctly once your FileServer returns data in the expected format.
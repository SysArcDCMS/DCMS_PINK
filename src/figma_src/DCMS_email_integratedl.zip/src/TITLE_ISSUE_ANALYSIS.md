# Medical Record Title Issue - "Untitled Medical Info"

## Issue Description
After manually editing FileUpload.tsx, medical records are showing "Untitled Medical Info" in the Documents tab instead of the actual title value.

## Analysis

### Where the Issue Appears
**Location:** `/app/dashboard/patients/[id]/page.tsx` - Documents Tab  
**Lines:** 1360-1373

```typescript
// Find the associated medical record to get the title
let recordTitle = 'Untitled Record';

if (recordType === 'medical_info') {
  const record = medicalInfo.find(r => r.id === file.recordId);
  recordTitle = record?.title || 'Untitled Medical Info';  // <-- Shows fallback
}
```

### Root Cause Analysis

The "Untitled Medical Info" text appears when **one of two conditions is true**:

1. **Medical record not found:** `medicalInfo.find(r => r.id === file.recordId)` returns `undefined`
2. **Medical record found but title is empty:** `record.title` is `undefined`, `null`, or empty string

## Most Likely Causes

### 1. ✅ RecordId Mismatch (MOST LIKELY)
**Problem:** Files are uploaded with `recordId='temp'`, but not updated to the actual record ID after creation.

**Evidence:**
- FileUpload component is initialized with `recordId={selectedRecord?.id || 'temp'}` (line 733)
- When adding new records, `selectedRecord` is `null`, so `recordId='temp'`
- Pending files are uploaded with `recordId='temp'`
- If file update fails or doesn't execute, file keeps `recordId='temp'`
- When displaying, `medicalInfo.find(r => r.id === 'temp')` returns `undefined`
- Falls back to "Untitled Medical Info"

**Solution:** Ensure files are properly updated with the real recordId after medical record creation (already implemented in handleAddRecord, lines 413-467)

### 2. Medical Record Creation Without Title
**Problem:** Medical record is created but the `title` field is empty in the database.

**Evidence:**
- Form captures title correctly (line 590)
- Title is sent in recordData (line 399: `...recordFormData`)
- But database record might not have the title saved

**Possible Reasons:**
- Supabase server-side validation strips the field
- Database column mismatch (e.g., column name is `recordTitle` not `title`)
- Database constraint or trigger issue

### 3. State Not Refreshing
**Problem:** Medical records are created correctly, but the local state isn't refreshing.

**Evidence:**
- After creating record, `fetchMedicalRecords(patient.email)` is called (line 457)
- But if this fetch fails or returns stale data, medicalInfo won't have the new record
- File would be displayed but record lookup fails

## Verification Steps

### Step 1: Check File recordId
```typescript
console.log('File recordId:', file.recordId);
console.log('Available medical records:', medicalInfo.map(r => r.id));
```

### Step 2: Check Medical Record Title
```typescript
const record = medicalInfo.find(r => r.id === file.recordId);
console.log('Found record:', record);
console.log('Record title:', record?.title);
```

### Step 3: Check Database
Query the Supabase database:
```sql
SELECT id, title, description, patientEmail 
FROM medical_records 
WHERE type = 'medical_info' 
ORDER BY dateRecorded DESC 
LIMIT 10;
```

Check if:
- Record exists
- Record has the title field populated
- Record ID matches file's recordId

## Fix Implementation

The fix has been implemented in `/app/dashboard/patients/[id]/page.tsx` (lines 413-467):

```typescript
// After record creation
if (response.ok) {
  const newRecordId = data.record?.id;
  
  // Upload pending files and update their recordId
  if (recordFileUploadRef.current?.hasPendingFiles() && newRecordId) {
    const uploadedFiles = await recordFileUploadRef.current.uploadPendingFiles();
    
    // Update all uploaded files with the real recordId
    for (const file of uploadedFiles) {
      await fetch('/api/files', {
        method: 'PUT',
        body: JSON.stringify({ fileId: file.id, recordId: newRecordId }),
      });
    }
  }
  
  // Also update any already-uploaded files
  if (recordFiles.length > 0 && newRecordId) {
    for (const file of recordFiles) {
      await fetch('/api/files', {
        method: 'PUT',
        body: JSON.stringify({ fileId: file.id, recordId: newRecordId }),
      });
    }
  }
}
```

## Testing

1. **Create new medical info record:**
   - Fill in title: "Test Medical Condition"
   - Add description
   - Add 1-2 files
   - Click "Add Medical Info"

2. **Verify in Documents tab:**
   - Check if files appear under "Medical Information"
   - Check if title shows "Test Medical Condition" not "Untitled Medical Info"

3. **Check browser console:**
   - Look for file update success logs: `"Successfully updated pending file: {fileId}"`
   - Look for any error messages

4. **Check database (optional):**
   - Query medical_records table for the new record
   - Query files table for the uploaded files
   - Verify recordId matches between tables

## Next Steps

1. **If issue persists after fix:**
   - Add console.log statements in Documents tab to see what data is available
   - Check if the medical record is actually in the `medicalInfo` array
   - Check if the file's `recordId` matches any record's `id`

2. **Check Supabase server:**
   - Verify `/api/medical-records` POST endpoint returns the full record
   - Verify the record includes the `title` field
   - Check Supabase Edge Function for any field transformations

3. **Database schema verification:**
   - Ensure `medical_records` table has a `title` column (for medical_info type)
   - Check if there are any constraints or triggers that might clear the field
   - Verify column data type (TEXT, VARCHAR, etc.)

## Files Modified

1. `/app/dashboard/patients/[id]/page.tsx` - Enhanced file update logic
2. `/components/FileUpload.tsx` - Already fixed in previous update
3. `/TITLE_ISSUE_ANALYSIS.md` - This documentation

## Related Issues

- File upload with temp recordId (FIXED)
- Progress bar at 0% (FIXED)
- Auto-upload files (FIXED)
- Horizontal scrollbar in modal (FIXED)

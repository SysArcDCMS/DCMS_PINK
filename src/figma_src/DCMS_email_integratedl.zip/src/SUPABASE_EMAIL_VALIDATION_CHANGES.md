# Supabase Server Email Validation Implementation

## Overview
Updated `/supabase/functions/server/index.tsx` to support the new email validation system with proper token management and user activation flow.

---

## Changes Made

### 1. Updated `/auth/signin` Endpoint
**Added email validation check before allowing login**

```typescript
// Check if email is validated (NEW: Email validation check)
if (user.emailValidated === false) {
  console.log('Login denied - email not validated:', email);
  return c.json({
    error: 'Please verify your email before logging in.',
    errorCode: 'EMAIL_NOT_VALIDATED'
  }, 403);
}
```

**Behavior:**
- Returns 403 Forbidden if user's `emailValidated` is false
- Includes `errorCode: 'EMAIL_NOT_VALIDATED'` for frontend handling
- This check happens after user exists check but before password validation
- Does NOT count as a failed login attempt (not an authentication failure)

---

### 2. Updated `/auth/signup` Endpoint
**Simplified to immediately create user with emailValidated=false**

```typescript
const newUser = {
  id: userId,
  email,
  password,
  first_name,
  last_name,
  name: fullName,
  phone: phone || null,
  role: 'patient',
  canLogin: false, // Cannot login until email is validated
  registrationType: 'registered',
  emailValidated: false, // Must validate email first
  createdAt: new Date().toISOString(),
  lastUpdatedAt: new Date().toISOString()
};

// Create user in database
await kv.set(`dcms:user:${email}`, newUser);
```

**Changes:**
- ❌ Removed: `requireEmailValidation` and `domain` parameters
- ❌ Removed: Token generation logic (moved to Next.js API)
- ❌ Removed: Validation link generation
- ✅ Added: Always set `emailValidated: false` on signup
- ✅ Added: Always set `canLogin: false` on signup
- ✅ Returns user ID and email (not full user object)

**Why?**
- Email sending is now handled by Next.js API route
- Supabase Edge Function just creates the user account
- Keeps separation of concerns (database vs email service)

---

### 3. Updated `/auth/validate-email` Endpoint
**Changed to accept only token (no email required)**

```typescript
POST /auth/validate-email
Body: { token }
```

**New Logic:**
1. Get token data from `dcms:email-validation-token:${token}`
2. Check if token exists and not expired
3. Check if token was already used
4. Get user from database using email from token
5. Update user: `emailValidated: true`, `canLogin: true`
6. Mark token as used
7. Return success with user's email

**Key Changes:**
- ❌ Removed: Email parameter requirement
- ✅ Added: Token usage tracking (`used` flag)
- ✅ Added: Better error messages
- ✅ Added: Token reuse prevention
- ✅ Changed: Updates existing user instead of creating new one

**Storage Keys:**
- `dcms:email-validation-token:${token}` - Token data
- `dcms:email-validation-index:${userId}` - User to token mapping

---

### 4. NEW: `/auth/store-validation-token` Endpoint
**Store validation token for a user**

```typescript
POST /auth/store-validation-token
Body: { userId, token, expiresAt }

Response: { success: true, message: "..." }
```

**Logic:**
1. Validate required fields (userId, token, expiresAt)
2. Find user by userId
3. Invalidate any existing tokens for this user
4. Store new token with metadata
5. Create index for quick lookup

**Storage:**
- `dcms:email-validation-token:${token}` - Main token data
- `dcms:email-validation-index:${userId}` - Index for user lookup

**Token Data Structure:**
```typescript
{
  userId: string,
  email: string,
  token: string,
  expiresAt: string, // ISO timestamp
  createdAt: string, // ISO timestamp
  used: boolean
}
```

**Called by:**
- `/api/auth/signup` - After creating user
- `/api/auth/resend-validation` - When generating new token

---

### 5. NEW: `/auth/check-validation-status` Endpoint
**Check if user exists and their validation status**

```typescript
POST /auth/check-validation-status
Body: { email }

Response: { userId, userName, emailValidated }
```

**Logic:**
1. Get user from database by email
2. Return 404 if user doesn't exist
3. Return user ID, full name, and validation status

**Used for:**
- Checking if user can resend validation email
- Verifying user exists before generating new token
- Preventing validation emails to non-existent accounts

**Response Example:**
```json
{
  "userId": "user-abc123",
  "userName": "John Doe",
  "emailValidated": false
}
```

**Called by:**
- `/api/auth/resend-validation` - Before sending new email

---

## Data Flow Diagram

### Signup Flow
```
1. Frontend: POST /api/auth/signup
   ↓
2. Next.js API: POST /supabase/auth/signup
   → Creates user with emailValidated=false
   ↓
3. Next.js API: POST /supabase/auth/store-validation-token
   → Stores token in KV
   ↓
4. Next.js API: sendValidationEmail()
   → Sends email via Nodemailer
   ↓
5. Frontend: Redirect to /signup-success
```

### Validation Flow
```
1. User clicks link: /validate-email?token=xxx
   ↓
2. Frontend: GET /api/auth/validate-email?token=xxx
   ↓
3. Next.js API: POST /supabase/auth/validate-email
   → Validates token
   → Updates user (emailValidated=true)
   → Marks token as used
   ↓
4. Frontend: Show success message
   ↓
5. User can now login
```

### Login Flow (Unvalidated)
```
1. User tries to login
   ↓
2. Frontend: POST /api/auth/login
   ↓
3. Next.js API: POST /supabase/auth/signin
   → Checks emailValidated field
   → Returns 403 if false
   ↓
4. Frontend: Shows error + resend button
```

### Resend Validation Flow
```
1. User clicks "Resend validation email"
   ↓
2. Frontend: POST /api/auth/resend-validation
   ↓
3. Next.js API: POST /supabase/auth/check-validation-status
   → Verify user exists
   ↓
4. Next.js API: POST /supabase/auth/store-validation-token
   → Generate and store new token
   ↓
5. Next.js API: sendResendValidationEmail()
   → Send new email
   ↓
6. Frontend: Show success message
```

---

## KV Store Schema

### User Data
**Key:** `dcms:user:${email}`

**Value:**
```typescript
{
  id: string,
  email: string,
  password: string,
  first_name: string,
  last_name: string,
  name: string,
  phone: string | null,
  role: 'patient' | 'dentist' | 'staff' | 'admin',
  canLogin: boolean,          // NEW: false until email validated
  registrationType: string,
  emailValidated: boolean,    // NEW: true when email verified
  createdAt: string,
  lastUpdatedAt: string
}
```

### Validation Token Data
**Key:** `dcms:email-validation-token:${token}`

**Value:**
```typescript
{
  userId: string,
  email: string,
  token: string,
  expiresAt: string,          // ISO timestamp (24 hours from creation)
  createdAt: string,
  used: boolean,              // false initially, true after validation
  usedAt?: string             // ISO timestamp when used (optional)
}
```

### Validation Token Index
**Key:** `dcms:email-validation-index:${userId}`

**Value:** `string` (token)

**Purpose:** Quick lookup of current token for a user

---

## API Endpoint Summary

| Endpoint | Method | Purpose | Changes |
|----------|--------|---------|---------|
| `/auth/signup` | POST | Create user account | ✏️ Updated - Creates user immediately |
| `/auth/signin` | POST | Login user | ✏️ Updated - Check emailValidated |
| `/auth/validate-email` | POST | Validate email token | ✏️ Updated - Token-only, update existing user |
| `/auth/store-validation-token` | POST | Store validation token | ✅ New |
| `/auth/check-validation-status` | POST | Check user validation status | ✅ New |

---

## Error Codes

### `/auth/signin`
- `401` - Invalid credentials
- `403` - Email not validated (`errorCode: 'EMAIL_NOT_VALIDATED'`)
- `403` - Walk-in patient cannot login
- `429` - Too many failed attempts (locked out)
- `500` - Server error

### `/auth/signup`
- `400` - Missing required fields
- `409` - User already exists
- `500` - Server error

### `/auth/validate-email`
- `400` - Missing token
- `400` - Token expired
- `400` - Token already used
- `400` - Email already validated
- `404` - Invalid token
- `404` - User not found
- `500` - Server error

### `/auth/store-validation-token`
- `400` - Missing required fields
- `404` - User not found
- `500` - Server error

### `/auth/check-validation-status`
- `400` - Missing email
- `404` - User not found
- `500` - Server error

---

## Testing

### Test Signup
```bash
curl -X POST https://your-project.supabase.co/functions/v1/make-server-c89a26e4/auth/signup \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -d '{
    "email": "test@example.com",
    "password": "Test123!",
    "first_name": "Test",
    "last_name": "User"
  }'
```

### Test Store Token
```bash
curl -X POST https://your-project.supabase.co/functions/v1/make-server-c89a26e4/auth/store-validation-token \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -d '{
    "userId": "user-abc123",
    "token": "def456",
    "expiresAt": "2025-10-11T12:00:00.000Z"
  }'
```

### Test Validate Email
```bash
curl -X POST https://your-project.supabase.co/functions/v1/make-server-c89a26e4/auth/validate-email \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -d '{
    "token": "def456"
  }'
```

### Test Check Status
```bash
curl -X POST https://your-project.supabase.co/functions/v1/make-server-c89a26e4/auth/check-validation-status \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -d '{
    "email": "test@example.com"
  }'
```

### Test Login (Unvalidated)
```bash
curl -X POST https://your-project.supabase.co/functions/v1/make-server-c89a26e4/auth/signin \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -d '{
    "email": "test@example.com",
    "password": "Test123!"
  }'

# Expected: 403 with EMAIL_NOT_VALIDATED error
```

---

## Security Considerations

### ✅ Token Security
- Tokens stored with userId and email for validation
- Tokens marked as `used` after validation (cannot reuse)
- Tokens expire after 24 hours
- Old tokens invalidated when new token generated

### ✅ User Privacy
- Passwords never returned in responses
- User lookup requires exact email match
- No information leakage about account existence

### ✅ Validation Flow
- User created immediately (prevents email enumeration)
- Cannot login until email validated
- Token required for validation (no bypass)
- One token per user at a time

---

## Migration Notes

### Existing Users
If you have existing users in the system, run a migration to add the `emailValidated` field:

```typescript
// Migration script (run once)
const allUsers = await kv.getByPrefix('dcms:user:');
for (const user of allUsers) {
  if (user.emailValidated === undefined) {
    // Set existing users as validated (they signed up before this feature)
    const updatedUser = {
      ...user,
      emailValidated: true,
      canLogin: user.canLogin !== false // Preserve existing canLogin logic
    };
    await kv.set(`dcms:user:${user.email}`, updatedUser);
  }
}
console.log('Migration complete');
```

### Walk-in Patients
Walk-in patients (created by staff) should remain unchanged:
- `canLogin: false`
- `emailValidated: false`
- They need to complete registration to enable login

---

## Troubleshooting

### Problem: User created but cannot login
**Check:**
1. Is `emailValidated` set to `true`?
2. Is `canLogin` set to `true`?
3. Run check-validation-status to see user state

### Problem: Token validation fails
**Check:**
1. Does token exist in `dcms:email-validation-token:${token}`?
2. Has token expired (check `expiresAt`)?
3. Was token already used (check `used` flag)?

### Problem: Cannot resend validation email
**Check:**
1. Does user exist in database?
2. Is user already validated?
3. Check rate limiting (3/hour in Next.js API)

---

## Performance Considerations

### KV Store Access Patterns
- **High frequency:** User lookups by email (signin, signup, check-status)
- **Medium frequency:** Token validation (once per user signup)
- **Low frequency:** Token storage (once per signup/resend)

### Cleanup Recommendations
Consider adding a cleanup job to remove:
- Expired tokens (older than 48 hours)
- Used tokens (after 7 days)
- Inactive unvalidated users (after 30 days)

### Example Cleanup Script
```typescript
// Run daily
const allTokens = await kv.getByPrefix('dcms:email-validation-token:');
const now = new Date();

for (const token of allTokens) {
  const expiry = new Date(token.expiresAt);
  const expired = now > expiry;
  const old = now.getTime() - new Date(token.createdAt).getTime() > 48 * 60 * 60 * 1000;
  
  if (expired && old) {
    await kv.del(`dcms:email-validation-token:${token.token}`);
    await kv.del(`dcms:email-validation-index:${token.userId}`);
    console.log(`Cleaned up expired token for user ${token.userId}`);
  }
}
```

---

## Next Steps

1. ✅ **Supabase server updated** - All endpoints implemented
2. ⏳ **Deploy Edge Function** - Push changes to Supabase
3. ⏳ **Test endpoints** - Use curl or Postman
4. ⏳ **Configure email service** - Set up Gmail app password
5. ⏳ **Test full flow** - Signup → Validate → Login
6. ⏳ **Monitor logs** - Check for errors in production

---

## Related Documentation

- `/EMAIL_VALIDATION_IMPLEMENTATION.md` - Complete system documentation
- `/EMAIL_VALIDATION_FILES_LIST.md` - Quick reference
- Supabase Edge Functions: https://supabase.com/docs/guides/functions
- Deno KV: https://deno.com/kv

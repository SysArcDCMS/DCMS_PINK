import { NextRequest, NextResponse } from 'next/server';
import { projectId, publicAnonKey } from '../../../utils/supabase/info';

export async function GET(request: NextRequest) {
  const startTime = Date.now();
  
  try {
    // Get query params to include restock requests and logs
    const url = new URL(request.url);
    const includeRequests = url.searchParams.get('includeRequests') !== 'false';
    const includeLogs = url.searchParams.get('includeLogs') !== 'false';

    const serverUrl = `https://${projectId}.supabase.co/functions/v1/make-server-c89a26e4/inventory?includeRequests=${includeRequests}&includeLogs=${includeLogs}`;

    const serverStartTime = Date.now();
    
    // Add timeout and better error handling
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000); // 8 second timeout

    const response = await fetch(
      serverUrl,
      {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        signal: controller.signal,
        // Add cache control for better performance
        next: { revalidate: 60 } // Revalidate every minute
      }
    );
    
    clearTimeout(timeoutId);
    const serverEndTime = Date.now();
    const serverQueryTime = serverEndTime - serverStartTime;

    // Server-side performance monitoring - log queries >1 second
    if (serverQueryTime > 1000) {
      console.warn(`[INVENTORY PERFORMANCE] Slow server query detected: ${serverQueryTime}ms`);
    }

    if (!response.ok) {
      // Try to get error details
      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        const errorData = await response.json();
        throw new Error(`Server error: ${errorData.error || response.statusText}`);
      } else {
        // If it's not JSON, likely an HTML error page
        const errorText = await response.text();
        console.error('[INVENTORY API] Server returned non-JSON error:', errorText.substring(0, 200));
        throw new Error(`Server error: ${response.status} ${response.statusText}`);
      }
    }

    // Validate response is JSON
    const contentType = response.headers.get('content-type');
    if (!contentType || !contentType.includes('application/json')) {
      const responseText = await response.text();
      console.error('[INVENTORY API] Server returned non-JSON response:', responseText.substring(0, 200));
      throw new Error('Server returned invalid response format');
    }

    const data = await response.json();
    const endTime = Date.now();
    const totalQueryTime = endTime - startTime;

    // Add performance metadata and fresh data indicators
    const now = new Date().toISOString();
    const responseData = {
      ...data,
      fetchedAt: now,
      isFresh: true,
      queryTime: totalQueryTime,
      serverQueryTime: serverQueryTime,
      timestamp: Date.now()
    };

    return NextResponse.json(responseData, {
      headers: {
        'Cache-Control': 'public, s-maxage=15, stale-while-revalidate=30', // Optimized for 15-second refresh
        'X-Fetched-At': now,
        'X-Query-Time': totalQueryTime.toString(),
        'X-Server-Query-Time': serverQueryTime.toString(),
        'X-Content-Type': 'application/json',
      },
    });

  } catch (error) {
    console.error('Inventory API route error:', error);
    
    // Better error classification
    let status = 500;
    let errorType = 'internal_error';
    let errorMessage = 'Unknown error';
    
    if (error instanceof Error) {
      errorMessage = error.message;
      
      if (error.name === 'AbortError') {
        status = 408;
        errorType = 'timeout';
        errorMessage = 'Server request timed out';
      } else if (errorMessage.includes('Failed to fetch') || errorMessage.includes('network')) {
        status = 503;
        errorType = 'network_error';
        errorMessage = 'Unable to connect to server';
      } else if (errorMessage.includes('Server error')) {
        status = 502;
        errorType = 'server_error';
      }
    }
    
    return NextResponse.json(
      { 
        error: 'Failed to fetch inventory',
        details: errorMessage,
        errorType,
        timestamp: new Date().toISOString(),
        // Provide fallback empty data structure
        items: [],
        restockRequests: [],
        logs: []
      },
      { 
        status,
        headers: {
          'Content-Type': 'application/json',
        }
      }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const itemData = await request.json();

    const response = await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-c89a26e4/inventory`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(itemData),
      }
    );

    if (!response.ok) {
      const errorData = await response.json();
      return NextResponse.json(errorData, { status: response.status });
    }

    const data = await response.json();
    return NextResponse.json(data);

  } catch (error) {
    console.error('Add inventory item API route error:', error);
    return NextResponse.json(
      { 
        error: 'Failed to add inventory item',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}
import { NextRequest, NextResponse } from 'next/server';
import { projectId, publicAnonKey } from '../../../../utils/supabase/info';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    const response = await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-c89a26e4/auth/signin`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify(body),
      }
    );

    const data = await response.json();

    if (!response.ok) {
      // Check if error is due to unvalidated email
      if (data.error?.includes('email not validated') || data.error?.includes('not verified')) {
        return NextResponse.json(
          {
            error: 'Please verify your email before logging in.',
            errorCode: 'EMAIL_NOT_VALIDATED',
            email: body.email,
          },
          { status: 403 }
        );
      }
      
      return NextResponse.json(data, { status: response.status });
    }

    // Success - check if email is validated
    if (data.user && !data.user.emailValidated) {
      return NextResponse.json(
        {
          error: 'Please verify your email before logging in.',
          errorCode: 'EMAIL_NOT_VALIDATED',
          email: body.email,
        },
        { status: 403 }
      );
    }

    return NextResponse.json(data);
  } catch (error) {
    console.error('[Login] Error:', error);
    return NextResponse.json(
      { error: 'Authentication service unavailable' },
      { status: 500 }
    );
  }
}
'use client';

import React, { useState } from 'react';
import { Button } from '../../components/ui/button';
import { CalendarPopover } from '../../components/CalendarPopover';
import { format } from 'date-fns';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';

export default function DebugPage() {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>();
  const [debugData, setDebugData] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const testMeriendaBreak = async () => {
    if (!selectedDate) {
      alert('Please select a date first');
      return;
    }

    setLoading(true);
    try {
      const requestData = {
        date: format(selectedDate, 'yyyy-MM-dd'),
        serviceDuration: 60,
        bufferTime: 15
      };

      console.log('🧪 Debug Test - Sending request:', requestData);

      const response = await fetch('/api/appointments/available-slots', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestData)
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      console.log('🧪 Debug Test - Received response:', data);
      
      // Enhanced debugging info
      const debugInfo = {
        ...data,
        requestData,
        timestamp: new Date().toISOString(),
        responseStatus: response.status
      };
      
      setDebugData(debugInfo);
      console.log('🧪 Debug Test - Complete debug info:', debugInfo);
    } catch (error) {
      console.error('🚨 Debug error:', error);
      setDebugData({
        error: error.message,
        timestamp: new Date().toISOString()
      });
    } finally {
      setLoading(false);
    }
  };

  const testMeriendaDirectly = async () => {
    setLoading(true);
    try {
      // Test directly against server endpoint
      const response = await fetch('/api/test-merienda');
      const data = await response.json();
      
      // Show results in debug data
      setDebugData({
        ...debugData,
        directTest: data
      });
      
      console.log('Direct merienda test:', data);
      alert(`Direct test complete! Check console or debug data. ${data.summary?.correctResults}/${data.summary?.totalTested} results correct.`);
    } catch (error) {
      console.error('Direct test error:', error);
      alert('Direct test failed - check console');
    } finally {
      setLoading(false);
    }
  };

  const testWithCacheBuster = async () => {
    if (!selectedDate) {
      alert('Please select a date first');
      return;
    }

    setLoading(true);
    try {
      const requestData = {
        date: format(selectedDate, 'yyyy-MM-dd'),
        serviceDuration: 60,
        bufferTime: 15,
        cacheBuster: Date.now() // Force no caching
      };

      console.log('🚀 Cache-busting Test - Sending request:', requestData);

      const response = await fetch('/api/appointments/available-slots', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0'
        },
        body: JSON.stringify(requestData)
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      console.log('🚀 Cache-busting Test - Received response:', data);
      
      setDebugData({
        ...data,
        requestData,
        testType: 'cache-busting',
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('🚨 Cache-busting test error:', error);
      setDebugData({
        error: error.message,
        testType: 'cache-busting',
        timestamp: new Date().toISOString()
      });
    } finally {
      setLoading(false);
    }
  };

  const checkServerStatus = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/server-status');
      const data = await response.json();
      
      console.log('🌐 Server Status:', data);
      alert(`Server Status: ${data.status}\nVersion: ${data.version}\nTime: ${data.timestamp}\nMerienda Break: ${data.breakTimes?.[1]?.start}-${data.breakTimes?.[1]?.end}`);
      
      setDebugData({
        ...debugData,
        serverStatus: data
      });
    } catch (error) {
      console.error('🚨 Server status error:', error);
      alert(`Server status check failed: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const checkMeriendaSlots = () => {
    if (!debugData?.slots) return [];
    
    // Check for slots around merienda time (3:00 PM)
    // Merienda break is 15:00-15:15, so any slots from 14:00-15:15 should be blocked
    const meriendaTimeSlots = debugData.slots.filter((slot: any) => 
      slot.startTime >= '14:00' && slot.startTime <= '15:15'
    );
    
    return meriendaTimeSlots;
  };

  const analyzeMeriendaBreak = () => {
    if (!debugData) return null;
    
    // Analyze what should be blocked for merienda break
    // Break: 15:00-15:15 (900-915 minutes)
    // Service: 60 min + 15 buffer = 75 minutes total
    // Any slot starting at 14:00 (840 min) would end at 915 min (15:15) - should conflict
    // Any slot starting at 13:45 (825 min) would end at 900 min (15:00) - should NOT conflict
    
    const problematicSlots = debugData.slots?.filter((slot: any) => {
      const [hour, minute] = slot.startTime.split(':').map(Number);
      const startMinutes = hour * 60 + minute;
      const endMinutes = startMinutes + 75; // 60 service + 15 buffer
      
      // Check if this overlaps with merienda break (900-915 minutes)
      return startMinutes < 915 && endMinutes > 900;
    }) || [];
    
    return {
      shouldBeBlocked: problematicSlots.length,
      actuallyAvailable: debugData.slots?.length || 0,
      problematicSlots: problematicSlots
    };
  };

  const meriendaAnalysis = analyzeMeriendaBreak();

  const meriendaSlots = checkMeriendaSlots();

  return (
    <div className="container mx-auto p-8 space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>🐛 Debug Tool - Merienda Break & Calendar Test</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          
          {/* Calendar Test */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">📅 Calendar Test</h3>
            <p className="text-sm text-gray-600">
              Test calendar popover auto-close and weekday alignment. Today is {format(new Date(), 'EEEE, MMM dd, yyyy')}.
            </p>
            
            <div className="w-64">
              <CalendarPopover
                date={selectedDate}
                onSelect={setSelectedDate}
                placeholder="Select a date to test"
              />
            </div>
            
            {selectedDate && (
              <p className="text-sm text-green-600">
                ✅ Selected: {format(selectedDate, 'EEEE, MMM dd, yyyy')}
              </p>
            )}
          </div>

          {/* Merienda Break Test */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">☕ Merienda Break Test</h3>
            <p className="text-sm text-gray-600">
              Test if 3:00-3:15 PM break is properly excluded from available slots.
            </p>
            
            <div className="flex gap-2 flex-wrap">
              <Button onClick={testMeriendaBreak} disabled={loading || !selectedDate}>
                {loading ? 'Testing...' : 'Test Merienda Break'}
              </Button>
              
              <Button 
                variant="outline" 
                onClick={testMeriendaDirectly} 
                disabled={loading}
              >
                Direct Server Test
              </Button>

              <Button 
                variant="secondary" 
                onClick={testWithCacheBuster} 
                disabled={loading || !selectedDate}
              >
                Force Refresh Test
              </Button>

              <Button 
                variant="outline" 
                onClick={checkServerStatus} 
                disabled={loading}
                size="sm"
              >
                Server Status
              </Button>
            </div>

            {debugData && (
              <div className="space-y-4">
                <div className="p-4 bg-gray-50 rounded">
                  <h4 className="font-medium">📊 Slot Summary</h4>
                  <p>Total available slots: {debugData.slots?.length || 0}</p>
                  <p>Date tested: {format(selectedDate!, 'yyyy-MM-dd')}</p>
                </div>

                {/* Merienda Time Analysis */}
                <div className="p-4 bg-blue-50 rounded">
                  <h4 className="font-medium">☕ Merienda Break Analysis</h4>
                  <div className="text-sm space-y-2">
                    <p><strong>Break Time:</strong> 3:00-3:15 PM (15:00-15:15)</p>
                    <p><strong>Service Duration:</strong> 60 min + 15 min buffer = 75 minutes</p>
                    <p><strong>Should be blocked:</strong> Slots from ~2:00-3:15 PM</p>
                  </div>
                  
                  {meriendaAnalysis && (
                    <div className="mt-3 p-3 bg-white rounded border">
                      <h5 className="font-medium text-sm">Analysis Results:</h5>
                      <div className="text-xs space-y-1">
                        <p>Slots that should overlap with break: <span className="font-mono bg-gray-100 px-1 rounded">{meriendaAnalysis.shouldBeBlocked}</span></p>
                        <p>Total available slots: <span className="font-mono bg-gray-100 px-1 rounded">{meriendaAnalysis.actuallyAvailable}</span></p>
                      </div>
                      
                      {meriendaAnalysis.problematicSlots.length > 0 ? (
                        <div className="mt-2">
                          <p className="text-red-600 font-medium">🚨 MERIENDA BREAK BROKEN!</p>
                          <p className="text-red-600 text-xs">These slots should be blocked but are available:</p>
                          <div className="grid grid-cols-4 gap-1 mt-1">
                            {meriendaAnalysis.problematicSlots.map((slot: any) => (
                              <div key={slot.startTime} className="p-1 bg-red-100 rounded text-xs text-red-700">
                                {slot.startTime}
                              </div>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <p className="text-green-600 font-medium mt-2">✅ Merienda break is working correctly!</p>
                      )}
                    </div>
                  )}
                  
                  {meriendaSlots.length > 0 && (
                    <div className="mt-3">
                      <p className="text-blue-700 mb-2 text-sm">Available slots in 2:00-3:15 PM range:</p>
                      <div className="grid grid-cols-6 gap-1">
                        {meriendaSlots.map((slot: any) => (
                          <div key={slot.startTime} className="p-1 bg-orange-100 rounded text-xs">
                            {slot.startTime}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* All Available Slots */}
                <div className="p-4 bg-green-50 rounded max-h-64 overflow-y-auto">
                  <h4 className="font-medium mb-2">✅ All Available Slots</h4>
                  <div className="grid grid-cols-6 gap-2">
                    {debugData.slots?.map((slot: any) => (
                      <div 
                        key={slot.startTime} 
                        className={`p-2 rounded text-xs ${
                          slot.startTime >= '14:00' && slot.startTime <= '15:15' 
                            ? 'bg-red-100 text-red-700' 
                            : 'bg-green-100 text-green-700'
                        }`}
                      >
                        {slot.startTime}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Debug Info */}
                {debugData.debug && (
                  <div className="p-4 bg-gray-50 rounded">
                    <h4 className="font-medium">🔍 Server Debug Info</h4>
                    <p>Total slots generated: {debugData.debug.totalSlots}</p>
                    <p>Available count: {debugData.debug.availableCount}</p>
                    
                    {/* Enhanced Merienda Analysis */}
                    {debugData.debug.meriendaAnalysis && (
                      <div className="mt-3 p-3 bg-yellow-50 rounded border">
                        <h5 className="font-medium text-yellow-800">☕ Server Merienda Analysis</h5>
                        <div className="text-xs space-y-1 text-yellow-700">
                          <p>Break time: {debugData.debug.meriendaAnalysis.breakTime}</p>
                          <p>Service total: {debugData.debug.meriendaAnalysis.serviceTotal}</p>
                          <p>Slots in merienda range: {debugData.debug.meriendaAnalysis.slotsInRange}</p>
                          <p>Blocked slots: {debugData.debug.meriendaAnalysis.blockedSlots}</p>
                          <p className={debugData.debug.meriendaAnalysis.availableSlots > 0 ? 'text-red-600 font-bold' : 'text-green-600'}>
                            Available slots in range: {debugData.debug.meriendaAnalysis.availableSlots}
                            {debugData.debug.meriendaAnalysis.availableSlots > 0 && ' ⚠️ BUG!'}
                          </p>
                        </div>
                      </div>
                    )}
                    
                    {debugData.debug.unavailableSlots?.length > 0 && (
                      <div className="mt-2">
                        <h5 className="font-medium">Blocked Slots:</h5>
                        <div className="text-xs space-y-1 max-h-32 overflow-y-auto">
                          {debugData.debug.unavailableSlots.map((slot: any, i: number) => (
                            <div key={i} className={`${slot.reason?.includes('Merienda') ? 'text-orange-600 font-medium' : 'text-red-600'}`}>
                              {slot.time}: {slot.reason}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Direct Test Results */}
            {debugData?.directTest && (
              <div className="p-4 bg-purple-50 rounded">
                <h4 className="font-medium text-purple-800">🔬 Direct Server Test Results</h4>
                <div className="text-sm space-y-2">
                  <p><strong>Status:</strong> {debugData.directTest.status}</p>
                  <p><strong>Test Summary:</strong> {debugData.directTest.summary?.correctResults}/{debugData.directTest.summary?.totalTested} correct</p>
                  <p><strong>Conflicts Found:</strong> {debugData.directTest.summary?.conflictsFound}</p>
                  <p><strong>Expected Conflicts:</strong> {debugData.directTest.summary?.expectedConflicts}</p>
                  
                  {debugData.directTest.results && (
                    <div className="mt-3">
                      <h5 className="font-medium">Test Results:</h5>
                      <div className="grid grid-cols-1 gap-1 text-xs max-h-32 overflow-y-auto">
                        {debugData.directTest.results.map((result: any, i: number) => (
                          <div 
                            key={i} 
                            className={`p-2 rounded ${
                              result.conflicts === result.expected 
                                ? 'bg-green-100 text-green-700' 
                                : 'bg-red-100 text-red-700'
                            }`}
                          >
                            <strong>{result.time}</strong>: {result.conflicts ? 'BLOCKED' : 'AVAILABLE'} 
                            {result.conflicts !== result.expected && ' ❌'}
                            {result.conflicts === result.expected && ' ✅'}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Instructions */}
          <div className="p-4 bg-yellow-50 rounded">
            <h4 className="font-medium text-yellow-800">📋 Test Instructions</h4>
            <ol className="list-decimal list-inside text-sm text-yellow-700 space-y-1">
              <li>First, test the calendar: click to open, select a date, verify it closes automatically</li>
              <li>Check that weekdays show as "Sun, Mon, Tue..." not "Mon dayname"</li>
              <li>Select today's date ({format(new Date(), 'MMM dd')}) and test merienda break</li>
              <li>Look for red slots between 2:00-3:15 PM - if present, merienda break is broken</li>
              <li>Green slots are properly available</li>
            </ol>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
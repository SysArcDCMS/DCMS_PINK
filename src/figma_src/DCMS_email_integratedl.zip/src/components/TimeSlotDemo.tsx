'use client';

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { TIME_SLOTS, TIME_SLOTS_DISPLAY, formatTimeSlotForDisplay } from '@/utils/timeUtils';

export function TimeSlotDemo() {
  return (
    <div className="w-full max-w-2xl mx-auto space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Time Slots Demo - Military Format</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            {TIME_SLOTS.map((time, index) => (
              <div key={index} className="p-3 bg-gray-100 rounded-md text-center">
                {time}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Time Slots Demo - AM/PM Format</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            {TIME_SLOTS_DISPLAY.map((time, index) => (
              <div key={index} className="p-3 bg-blue-100 rounded-md text-center">
                {time}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Time Range Demo</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="p-3 bg-green-100 rounded-md">
              <strong>Military Format:</strong> 09:00-10:00
            </div>
            <div className="p-3 bg-green-200 rounded-md">
              <strong>Formatted:</strong> {formatTimeSlotForDisplay('09:00-10:00')}
            </div>
            <div className="p-3 bg-yellow-100 rounded-md">
              <strong>Military Format:</strong> 14:30-15:30
            </div>
            <div className="p-3 bg-yellow-200 rounded-md">
              <strong>Formatted:</strong> {formatTimeSlotForDisplay('14:30-15:30')}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
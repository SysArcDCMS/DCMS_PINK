# Google Drive Integration

## Overview

The Go-Goyagoy DCMS uses Google Drive as the file storage solution for all medical records, patient documents, and diagnostic images. This provides secure, scalable, and reliable cloud storage with built-in versioning and sharing capabilities.

## Features

- **Secure Cloud Storage**: All files stored in Google Drive with encryption
- **Organized Folder Structure**: Automatic patient-based folder organization
- **Unlimited Storage**: Leverage Google Drive's storage capacity
- **File Sharing**: Easy sharing with patients and healthcare providers
- **Version Control**: Google Drive's built-in version history
- **Direct Links**: Direct download and preview links for files
- **Metadata Tracking**: Custom properties for advanced filtering and search

## Architecture

### Folder Structure
```
Root Folder (DCMS)
├── patient@example.com/
│   ├── medical_info/
│   │   ├── x-rays/
│   │   ├── photos/
│   │   └── documents/
│   ├── allergy/
│   ├── medication/
│   └── correction_request/
└── another-patient@example.com/
    └── ...
```

### File Metadata
Each file uploaded to Google Drive includes custom properties:
- `recordId` - Associated record ID
- `recordType` - Type of medical record
- `patientId` - Patient UUID
- `patientEmail` - Patient email address
- `uploadedBy` - Staff/dentist email who uploaded
- `uploadedByName` - Full name of uploader
- `uploadedAt` - ISO timestamp of upload

## Setup Instructions

### 1. Create Google Cloud Project

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing project
3. Name: "Go-Goyagoy DCMS" or similar

### 2. Enable Google Drive API

1. Navigate to **APIs & Services** > **Library**
2. Search for "Google Drive API"
3. Click **Enable**

### 3. Create OAuth 2.0 Credentials

1. Navigate to **APIs & Services** > **Credentials**
2. Click **Create Credentials** > **OAuth client ID**
3. Configure OAuth consent screen if prompted:
   - User Type: Internal (for organization) or External (for public)
   - App name: "Go-Goyagoy DCMS"
   - User support email: Your email
   - Developer contact: Your email
4. Application type: **Web application**
5. Name: "DCMS File Upload"
6. Authorized redirect URIs: Add your callback URL
   - Development: `http://localhost:3000/api/auth/google/callback`
   - Production: `https://yourdomain.com/api/auth/google/callback`
7. Click **Create**
8. Save the **Client ID** and **Client Secret**

### 4. Get Refresh Token

You need to obtain a refresh token to access Google Drive without user interaction:

#### Option A: Using OAuth Playground

1. Go to [OAuth 2.0 Playground](https://developers.google.com/oauthplayground/)
2. Click the gear icon (⚙️) in top right
3. Check "Use your own OAuth credentials"
4. Enter your Client ID and Client Secret
5. In "Step 1 - Select & authorize APIs":
   - Find "Drive API v3"
   - Select `https://www.googleapis.com/auth/drive.file`
   - Click "Authorize APIs"
6. Sign in with your Google account
7. Click "Allow" to grant permissions
8. In "Step 2 - Exchange authorization code for tokens":
   - Click "Exchange authorization code for tokens"
9. Copy the **Refresh token** from the response

#### Option B: Using Custom Script

Create a one-time script to get the refresh token:

```javascript
const { google } = require('googleapis');

const oauth2Client = new google.auth.OAuth2(
  'YOUR_CLIENT_ID',
  'YOUR_CLIENT_SECRET',
  'YOUR_REDIRECT_URI'
);

// Generate auth URL
const authUrl = oauth2Client.generateAuthUrl({
  access_type: 'offline',
  scope: ['https://www.googleapis.com/auth/drive.file'],
});

console.log('Visit this URL:', authUrl);
// After visiting the URL and authorizing, you'll get a code
// Exchange it for tokens:
// const { tokens } = await oauth2Client.getToken(code);
// console.log('Refresh token:', tokens.refresh_token);
```

### 5. Create Root Folder in Google Drive

1. Go to [Google Drive](https://drive.google.com)
2. Create a new folder named "DCMS Medical Records" or similar
3. Right-click the folder > **Get link** > **Copy link**
4. Extract the folder ID from the URL:
   - URL format: `https://drive.google.com/drive/folders/FOLDER_ID_HERE`
   - Copy the `FOLDER_ID_HERE` part

### 6. Configure Environment Variables

Add these variables to your `.env.local` file:

```env
# Google Drive Configuration
GOOGLE_DRIVE_CLIENT_ID=your_client_id_here
GOOGLE_DRIVE_CLIENT_SECRET=your_client_secret_here
GOOGLE_DRIVE_REDIRECT_URI=http://localhost:3000/api/auth/google/callback
GOOGLE_DRIVE_REFRESH_TOKEN=your_refresh_token_here
GOOGLE_DRIVE_ROOT_FOLDER=your_root_folder_id_here
```

## API Usage

### Upload File

```typescript
POST /api/files
Content-Type: multipart/form-data

FormData:
- file: File
- recordId: string
- recordType: 'medical_info' | 'allergy' | 'medication' | 'correction_request'
- patientId: string
- patientEmail: string
- uploadedBy: string
- uploadedByName: string
- description: string (optional)
```

**Response:**
```json
{
  "file": {
    "id": "google-drive-file-id",
    "fileName": "x-ray.jpg",
    "originalFileName": "x-ray.jpg",
    "fileType": "image/jpeg",
    "fileSize": 1234567,
    "recordId": "record-uuid",
    "recordType": "medical_info",
    "patientId": "patient-uuid",
    "patientEmail": "patient@example.com",
    "uploadedBy": "dr.smith@clinic.com",
    "uploadedByName": "Dr. Robert Smith",
    "description": "Periapical X-ray of tooth 21",
    "uploadedAt": "2024-12-06T10:00:00Z",
    "webViewLink": "https://drive.google.com/file/d/...",
    "webContentLink": "https://drive.google.com/...",
    "thumbnailLink": "https://drive.google.com/..."
  }
}
```

### List Files

```typescript
GET /api/files?patientEmail=patient@example.com&recordType=medical_info
```

**Response:**
```json
{
  "files": [
    {
      "id": "file-id-1",
      "fileName": "x-ray.jpg",
      "fileType": "image/jpeg",
      "fileSize": 1234567,
      "uploadedAt": "2024-12-06T10:00:00Z",
      "webViewLink": "https://drive.google.com/...",
      "webContentLink": "https://drive.google.com/...",
      "thumbnailLink": "https://drive.google.com/..."
    }
  ]
}
```

### Download File

```typescript
GET /api/files/[fileId]
```

**Response:** Binary file data with appropriate headers

### Delete File

```typescript
DELETE /api/files/[fileId]
```

**Response:**
```json
{
  "success": true,
  "message": "File deleted successfully"
}
```

## Component Usage

### FileUpload Component

The FileUpload component works seamlessly with Google Drive:

```tsx
import FileUpload from '@/components/FileUpload';

<FileUpload
  recordId={record.id}
  recordType="medical_info"
  patientId={patient.id}
  patientEmail={patient.email}
  uploadedBy={currentUser.email}
  uploadedByName={`${currentUser.first_name} ${currentUser.last_name}`}
  files={medicalFiles}
  onFilesChange={setMedicalFiles}
  maxFiles={10}
/>
```

## File Management Best Practices

### File Organization
1. **Automatic Folder Creation**: System automatically creates patient folders
2. **Record Type Subfolders**: Files organized by record type
3. **Metadata Tagging**: All files tagged with searchable metadata
4. **Naming Convention**: Keep original file names for easy identification

### Security
1. **Private by Default**: Files are private to the DCMS application
2. **Controlled Sharing**: Set permissions programmatically
3. **Access Logging**: Google Drive tracks all access
4. **Encryption**: Files encrypted at rest and in transit

### Storage Management
1. **Monitor Quota**: Check Google Drive storage usage regularly
2. **Cleanup Old Files**: Implement retention policies
3. **Archive Inactive Records**: Move to archive folder after retention period
4. **Duplicate Detection**: Prevent duplicate uploads

## Advanced Features

### Sharing Files with Patients

```typescript
import { googleDrive } from '@/utils/googleDrive';

// Grant read access to patient
await googleDrive.setFilePermissions(
  fileId,
  'reader',
  'user',
  patient.email
);
```

### Batch Operations

```typescript
// Upload multiple files
const uploadPromises = files.map(file => 
  googleDrive.uploadFile(file, options)
);
const results = await Promise.all(uploadPromises);
```

### Search Files

```typescript
// Search by metadata
const files = await googleDrive.searchByMetadata({
  patientEmail: 'patient@example.com',
  recordType: 'medical_info',
});
```

### List Files with Pagination

```typescript
let allFiles = [];
let pageToken = undefined;

do {
  const result = await googleDrive.listFiles({
    folderId: patientFolderId,
    pageSize: 100,
    pageToken,
  });
  
  allFiles.push(...result.files);
  pageToken = result.nextPageToken;
} while (pageToken);
```

## Troubleshooting

### Common Issues

**Issue: "Invalid credentials" error**
- Solution: Verify Client ID, Client Secret, and Refresh Token are correct
- Regenerate refresh token if expired

**Issue: "Insufficient permissions" error**
- Solution: Ensure OAuth scopes include `https://www.googleapis.com/auth/drive.file`
- Re-authorize with correct scopes

**Issue: "Folder not found" error**
- Solution: Verify GOOGLE_DRIVE_ROOT_FOLDER ID is correct
- Ensure the service account has access to the folder

**Issue: Files not appearing in search**
- Solution: Metadata properties may take time to index
- Use folder-based queries as fallback

### Rate Limits

Google Drive API has rate limits:
- **Per-user limit**: 1,000 requests per 100 seconds
- **Per-project limit**: 20,000 requests per 100 seconds

**Mitigation:**
- Implement exponential backoff for retries
- Batch operations when possible
- Cache file metadata locally

### Token Refresh

The system automatically refreshes access tokens. If issues occur:
1. Check refresh token is valid
2. Verify OAuth consent screen is published
3. Ensure redirect URIs match exactly

## Migration from FileServer

If migrating from existing FileServer:

### 1. Export Existing Files
```bash
# Backup current files
rsync -av /path/to/fileserver/uploads /backup/location
```

### 2. Upload to Google Drive
```javascript
// Migration script
import { googleDrive } from './utils/googleDrive';
import fs from 'fs';
import path from 'path';

async function migrateFiles() {
  const files = fs.readdirSync('/path/to/uploads');
  
  for (const fileName of files) {
    const filePath = path.join('/path/to/uploads', fileName);
    const fileBuffer = fs.readFileSync(filePath);
    const file = new Blob([fileBuffer]);
    
    await googleDrive.uploadFile(file, {
      fileName,
      mimeType: getMimeType(fileName),
      metadata: extractMetadata(fileName),
    });
  }
}
```

### 3. Update Database References
```sql
-- Update file references in database
UPDATE medical_records
SET file_path = REPLACE(file_path, '/uploads/', 'gdrive://')
WHERE file_path LIKE '/uploads/%';
```

### 4. Switch Environment Variables
```env
# Comment out FileServer
# FILE_SERVER_URL=http://localhost:9000

# Enable Google Drive
GOOGLE_DRIVE_CLIENT_ID=...
```

## Performance Optimization

### Caching Strategies
1. **Metadata Caching**: Cache file metadata in database
2. **Thumbnail Generation**: Use Google Drive thumbnails
3. **CDN Integration**: Use Google Drive's CDN for faster access
4. **Background Processing**: Upload files asynchronously

### Best Practices
1. **Parallel Uploads**: Upload multiple files simultaneously
2. **Resumable Uploads**: For files > 5MB
3. **Compression**: Compress before upload when appropriate
4. **Lazy Loading**: Load file lists on demand

## Security Considerations

### Data Protection
1. **Encryption**: All files encrypted by Google
2. **Access Control**: Implement role-based access
3. **Audit Trail**: Track all file operations
4. **Compliance**: HIPAA-compliant when configured properly

### HIPAA Compliance
To ensure HIPAA compliance:
1. Sign Google's BAA (Business Associate Agreement)
2. Enable encryption at rest and in transit
3. Implement proper access controls
4. Maintain audit logs
5. Regular security reviews

## Related Documentation

- [Medical Records](./medical-records.md) - File management workflow
- [API Reference](./api-reference.md#files) - Files API documentation
- [Components](./components.md#file-upload) - FileUpload component details
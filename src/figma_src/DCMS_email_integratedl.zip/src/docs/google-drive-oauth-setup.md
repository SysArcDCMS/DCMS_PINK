# Google Drive OAuth Setup - Troubleshooting Guide

## Error: redirect_uri_mismatch

### Problem
You're seeing this error when trying to use OAuth Playground:
```
Error 400: redirect_uri_mismatch
Request details: redirect_uri=https://developers.google.com/oauthplayground
```

### Solution

You have **3 options** to fix this:

---

## Option 1: Add OAuth Playground to Authorized Redirect URIs (Easiest)

### Steps:

1. **Go to Google Cloud Console**
   - Visit: https://console.cloud.google.com/

2. **Select Your Project**
   - Click project dropdown at top
   - Select your "Go-Goyagoy DCMS" project

3. **Navigate to Credentials**
   - Click hamburger menu (☰) → **APIs & Services** → **Credentials**

4. **Edit OAuth Client**
   - Find your OAuth 2.0 Client ID
   - Click the pencil icon (✏️) to edit

5. **Add OAuth Playground URI**
   - In "Authorized redirect URIs" section, click **+ ADD URI**
   - Add: `https://developers.google.com/oauthplayground`
   - Click **SAVE**

6. **Use OAuth Playground**
   - Now go to: https://developers.google.com/oauthplayground/
   - Follow the steps in the original guide

---

## Option 2: Use Custom Script (Recommended for Production)

This method doesn't require the OAuth Playground and is more secure.

### Step-by-Step Guide:

1. **Create a temporary script file**
   - Save this as `get-refresh-token.js` in your project root:

```javascript
#!/usr/bin/env node

/**
 * Google Drive Refresh Token Generator
 * This script helps you get a refresh token for Google Drive API
 */

const http = require('http');
const url = require('url');
const { exec } = require('child_process');

// Replace these with your OAuth credentials
const CLIENT_ID = 'YOUR_CLIENT_ID_HERE';
const CLIENT_SECRET = 'YOUR_CLIENT_SECRET_HERE';
const REDIRECT_URI = 'http://localhost:3000/oauth/callback';
const SCOPES = 'https://www.googleapis.com/auth/drive.file';

console.log('='.repeat(60));
console.log('Google Drive Refresh Token Generator');
console.log('='.repeat(60));
console.log();

// Step 1: Generate authorization URL
const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?` +
  `client_id=${encodeURIComponent(CLIENT_ID)}&` +
  `redirect_uri=${encodeURIComponent(REDIRECT_URI)}&` +
  `response_type=code&` +
  `scope=${encodeURIComponent(SCOPES)}&` +
  `access_type=offline&` +
  `prompt=consent`;

console.log('Step 1: Opening browser for authorization...');
console.log();
console.log('If the browser doesn\'t open automatically, visit this URL:');
console.log(authUrl);
console.log();

// Open browser
const platform = process.platform;
const openCommand = platform === 'darwin' ? 'open' : 
                   platform === 'win32' ? 'start' : 'xdg-open';
exec(`${openCommand} "${authUrl}"`);

// Step 2: Start local server to receive callback
const server = http.createServer(async (req, res) => {
  const queryObject = url.parse(req.url, true).query;
  
  if (queryObject.code) {
    const code = queryObject.code;
    
    // Exchange code for tokens
    try {
      const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          code,
          client_id: CLIENT_ID,
          client_secret: CLIENT_SECRET,
          redirect_uri: REDIRECT_URI,
          grant_type: 'authorization_code',
        }),
      });

      const tokens = await tokenResponse.json();

      if (tokens.refresh_token) {
        // Success!
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(`
          <html>
            <head><title>Success!</title></head>
            <body style="font-family: Arial; padding: 50px; text-align: center;">
              <h1 style="color: green;">✓ Success!</h1>
              <p>You can close this window and return to your terminal.</p>
            </body>
          </html>
        `);

        console.log();
        console.log('='.repeat(60));
        console.log('SUCCESS! Your refresh token:');
        console.log('='.repeat(60));
        console.log();
        console.log(tokens.refresh_token);
        console.log();
        console.log('='.repeat(60));
        console.log('Add this to your .env.local file:');
        console.log('='.repeat(60));
        console.log();
        console.log(`GOOGLE_DRIVE_REFRESH_TOKEN=${tokens.refresh_token}`);
        console.log();
        
        server.close();
        process.exit(0);
      } else {
        throw new Error('No refresh token received');
      }
    } catch (error) {
      res.writeHead(500, { 'Content-Type': 'text/html' });
      res.end(`
        <html>
          <head><title>Error</title></head>
          <body style="font-family: Arial; padding: 50px; text-align: center;">
            <h1 style="color: red;">✗ Error</h1>
            <p>${error.message}</p>
            <p>Check your terminal for details.</p>
          </body>
        </html>
      `);
      
      console.error('Error getting tokens:', error);
      server.close();
      process.exit(1);
    }
  } else if (queryObject.error) {
    res.writeHead(400, { 'Content-Type': 'text/html' });
    res.end(`
      <html>
        <head><title>Error</title></head>
        <body style="font-family: Arial; padding: 50px; text-align: center;">
          <h1 style="color: red;">✗ Authorization Denied</h1>
          <p>${queryObject.error}</p>
        </body>
      </html>
    `);
    
    console.error('Authorization error:', queryObject.error);
    server.close();
    process.exit(1);
  }
});

server.listen(3000, () => {
  console.log('Step 2: Waiting for authorization...');
  console.log('(Local server running on http://localhost:3000)');
  console.log();
});
```

2. **Update the script with your credentials**
   - Replace `YOUR_CLIENT_ID_HERE` with your actual Client ID
   - Replace `YOUR_CLIENT_SECRET_HERE` with your actual Client Secret

3. **Add redirect URI to Google Cloud Console**
   - Go to Google Cloud Console → Credentials
   - Edit your OAuth client
   - Add redirect URI: `http://localhost:3000/oauth/callback`
   - Click SAVE

4. **Run the script**
   ```bash
   node get-refresh-token.js
   ```

5. **Follow the prompts**
   - Browser will open automatically
   - Sign in to Google
   - Click "Allow" to grant permissions
   - Script will display your refresh token

6. **Copy the refresh token**
   - Add it to your `.env.local` file

---

## Option 3: Manual cURL Method

If you prefer command-line tools:

### Step 1: Get Authorization Code

1. **Build the authorization URL** (replace `YOUR_CLIENT_ID`):
   ```
   https://accounts.google.com/o/oauth2/v2/auth?client_id=YOUR_CLIENT_ID&redirect_uri=http://localhost:3000&response_type=code&scope=https://www.googleapis.com/auth/drive.file&access_type=offline&prompt=consent
   ```

2. **Visit the URL in browser**
   - Sign in to Google
   - Click "Allow"

3. **Copy the code from redirect**
   - You'll be redirected to: `http://localhost:3000/?code=AUTHORIZATION_CODE`
   - Copy the `AUTHORIZATION_CODE` part

### Step 2: Exchange Code for Refresh Token

Run this cURL command (replace placeholders):

```bash
curl -X POST https://oauth2.googleapis.com/token \
  -H "Content-Type: application/json" \
  -d '{
    "code": "YOUR_AUTHORIZATION_CODE",
    "client_id": "YOUR_CLIENT_ID",
    "client_secret": "YOUR_CLIENT_SECRET",
    "redirect_uri": "http://localhost:3000",
    "grant_type": "authorization_code"
  }'
```

The response will include your refresh token:
```json
{
  "access_token": "...",
  "refresh_token": "1//0a1b2c3d4e5f6g7h8i9j",
  "expires_in": 3600,
  "token_type": "Bearer"
}
```

---

## Complete Setup Checklist

Once you have your refresh token, complete the setup:

### 1. Environment Variables

Add to `.env.local`:

```env
# Google Drive Configuration
GOOGLE_DRIVE_CLIENT_ID=your_client_id
GOOGLE_DRIVE_CLIENT_SECRET=your_client_secret
GOOGLE_DRIVE_REDIRECT_URI=http://localhost:3000/oauth/callback
GOOGLE_DRIVE_REFRESH_TOKEN=your_refresh_token
GOOGLE_DRIVE_ROOT_FOLDER=your_folder_id
```

### 2. Create Root Folder

1. Go to Google Drive: https://drive.google.com
2. Create new folder: "DCMS Medical Records"
3. Right-click folder → Get link → Copy link
4. Extract folder ID from URL:
   - URL: `https://drive.google.com/drive/folders/1a2b3c4d5e6f7g8h9i0j`
   - Folder ID: `1a2b3c4d5e6f7g8h9i0j`
5. Add to `.env.local` as `GOOGLE_DRIVE_ROOT_FOLDER`

### 3. Test the Integration

Run the setup script:
```bash
node scripts/setup-google-drive.js
```

Or test directly:
```bash
# Start dev server
npm run dev

# Test file upload through the UI
# Go to: http://localhost:3000/dashboard/files
```

---

## Troubleshooting

### Issue: "Invalid client" error
**Solution**: 
- Verify CLIENT_ID and CLIENT_SECRET are correct
- Make sure you're using credentials from the same project

### Issue: "Access denied" error
**Solution**: 
- Ensure Google Drive API is enabled in your project
- Check that you've published the OAuth consent screen

### Issue: No refresh token received
**Solution**: 
- Make sure `access_type=offline` is in the auth URL
- Include `prompt=consent` to force re-consent
- Use a Google account that hasn't authorized the app before

### Issue: Refresh token stops working
**Solution**: 
- Tokens can expire if not used for 6 months
- Revoke access and generate a new token
- Check if OAuth consent screen is still published

---

## Security Best Practices

### Protect Your Credentials

1. **Never commit credentials to git**
   ```bash
   # Add to .gitignore
   echo ".env.local" >> .gitignore
   ```

2. **Use environment variables**
   - Development: `.env.local`
   - Production: Set in hosting platform (Vercel, etc.)

3. **Rotate tokens regularly**
   - Generate new refresh tokens every 6 months
   - Revoke old tokens when no longer needed

### OAuth Consent Screen

For production:
1. **Verify your domain**
2. **Complete OAuth consent screen**
3. **Submit for verification** if using sensitive scopes
4. **Add privacy policy URL**
5. **Add terms of service URL**

---

## Quick Reference

### Required Google Drive API Scopes

```
https://www.googleapis.com/auth/drive.file
```

This scope allows:
- ✅ Upload files created by the app
- ✅ Read files created by the app
- ✅ Delete files created by the app
- ✅ Create folders
- ❌ Access files created by other apps (more secure)

### Alternative Scopes (if needed)

For full Drive access:
```
https://www.googleapis.com/auth/drive
```

For read-only access:
```
https://www.googleapis.com/auth/drive.readonly
```

---

## Next Steps

After getting your refresh token:

1. ✅ Add all environment variables to `.env.local`
2. ✅ Create root folder in Google Drive
3. ✅ Run `node scripts/setup-google-drive.js` to verify
4. ✅ Test file upload in your application
5. ✅ Check `/dashboard/files` page works
6. ✅ Review security settings
7. ✅ Document your setup for team

---

## Support

### Official Documentation
- [Google OAuth 2.0](https://developers.google.com/identity/protocols/oauth2)
- [Google Drive API](https://developers.google.com/drive/api)
- [OAuth Playground](https://developers.google.com/oauthplayground/)

### Project Documentation
- [Google Drive Integration Guide](./google-drive-integration.md)
- [File Upload Summary](../FILE_UPLOADS_SUMMARY.md)
- [Migration Guide](../GOOGLE_DRIVE_MIGRATION.md)

---

**Last Updated**: December 2024  
**Status**: Production Ready  
**Difficulty**: Intermediate

'use client';

import { ReportsDashboard } from '../../../components/ReportsDashboard';

export default function ReportsPage() {
  return <ReportsDashboard />;
}
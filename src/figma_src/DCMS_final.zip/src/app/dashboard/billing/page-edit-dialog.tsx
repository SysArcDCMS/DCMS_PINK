      {/* Edit Bill Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit className="h-5 w-5" />
              Record Payment
            </DialogTitle>
            <DialogDescription>
              Add a payment for this bill. Outstanding balance: {selectedBill ? formatCurrency(selectedBill.outstandingBalance) : ''}
            </DialogDescription>
          </DialogHeader>
          {selectedBill && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="paymentAmount">Payment Amount</Label>
                <Input
                  id="paymentAmount"
                  type="number"
                  value={editForm.paymentAmount}
                  onChange={(e) => setEditForm(prev => ({
                    ...prev,
                    paymentAmount: Number(e.target.value)
                  }))}
                  min={0}
                  max={selectedBill.outstandingBalance}
                  placeholder="Enter payment amount"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="paymentMethod">Payment Method</Label>
                <Select
                  value={editForm.paymentMethod}
                  onValueChange={(value) => setEditForm(prev => ({
                    ...prev,
                    paymentMethod: value
                  }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select payment method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cash">Cash</SelectItem>
                    <SelectItem value="card">Card</SelectItem>
                    <SelectItem value="gcash">GCash</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="notes">Notes (Optional)</Label>
                <Textarea
                  id="notes"
                  value={editForm.notes}
                  onChange={(e) => setEditForm(prev => ({
                    ...prev,
                    notes: e.target.value
                  }))}
                  placeholder="Add payment notes..."
                  rows={3}
                />
              </div>
              
              <Separator />
              
              <div className="flex gap-3 pt-4">
                <Button 
                  variant="outline" 
                  onClick={() => setIsEditDialogOpen(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleUpdateBill}
                  disabled={isSubmitting || editForm.paymentAmount <= 0 || !editForm.paymentMethod}
                  className="flex-1"
                >
                  {isSubmitting ? 'Recording...' : 'Record Payment'}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
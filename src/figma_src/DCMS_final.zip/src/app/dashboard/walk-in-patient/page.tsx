'use client';

import { useAuth } from '../../../contexts/AuthContext';
import { WalkInPatient } from '../../../components/WalkInPatient';
import { Card, CardContent } from '../../../components/ui/card';

export default function WalkInPatientPage() {
  const { user } = useAuth();

  // Only staff and admin can access this page
  if (user?.role !== 'admin' && user?.role !== 'staff') {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-gray-500">Access denied. Only staff and administrators can register walk-in patients.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Walk-in Patient Registration</h1>
        <p className="text-gray-600 mt-2">
          {user?.role === 'staff' 
            ? 'Register patients who walk in without prior appointments (requires admin confirmation)'
            : 'Register patients who walk in without prior appointments'
          }
        </p>
      </div>
      
      <div className="max-w-4xl">
        <WalkInPatient 
          staffEmail={user?.email || ''} 
          onSuccess={() => {
            // The component will handle success feedback
          }}
        />
      </div>

      <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <h3 className="font-medium text-blue-900 mb-2">Walk-in Patient Process</h3>
        <ul className="text-sm text-blue-800 space-y-1">
          <li>• Walk-in patients are recorded in the system but cannot login initially</li>
          <li>• All appointments created here default to "pending" status</li>
          <li>• Admin users can confirm appointment details before they become active</li>
          <li>• Patients can register later using the same email to gain login access</li>
          <li>• {user?.role === 'staff' ? 'You can register walk-in patients, but appointment confirmation requires admin approval' : 'As admin, you can both register and confirm appointments'}</li>
        </ul>
      </div>
    </div>
  );
}
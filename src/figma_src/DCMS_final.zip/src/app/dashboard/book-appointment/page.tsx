'use client';

import React from 'react';
import { useAuth } from '../../../contexts/AuthContext';
import { useRouter } from 'next/navigation';
import { BookingForm } from '../../../components/BookingForm';

export default function BookAppointmentPage() {
  const { user } = useAuth();
  const router = useRouter();

  const handleSuccess = () => {
    // Redirect to appointments page after successful booking
    router.push('/dashboard/appointments');
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-2xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Book Appointment</h1>
          <p className="text-gray-600 mt-2">
            Schedule your dental appointment using our smart booking system
          </p>
        </div>
        
        <BookingForm
          userEmail={user?.email}
          userName={user?.name}
          userPhone={user?.phone}
          onSuccess={handleSuccess}
          asDialog={false}
        />
      </div>
    </div>
  );
}
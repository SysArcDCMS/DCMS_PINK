'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useServices } from '../contexts/ServiceContext';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription, DialogFooter } from './ui/dialog';
import { MessageSquare, Check, X, Clock, User, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner@2.0.3';
import { ServiceSuggestion } from '../types';

interface ServiceSuggestionsProps {
  className?: string;
}

export function ServiceSuggestions({ className }: ServiceSuggestionsProps) {
  const { user } = useAuth();
  const { 
    serviceSuggestions, 
    canViewSuggestions, 
    reviewServiceSuggestion,
    fetchServiceSuggestions 
  } = useServices();
  
  const [selectedSuggestion, setSelectedSuggestion] = useState<ServiceSuggestion | null>(null);
  const [reviewNotes, setReviewNotes] = useState('');
  const [isApproveDialogOpen, setIsApproveDialogOpen] = useState(false);
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch suggestions on component mount
  useEffect(() => {
    if (canViewSuggestions) {
      fetchServiceSuggestions();
    }
  }, [canViewSuggestions, fetchServiceSuggestions]);

  // Filter pending suggestions only
  const pendingSuggestions = serviceSuggestions.filter(s => s.status === 'pending');

  const formatDateTime = (dateString: string) => {
    try {
      return format(new Date(dateString), 'MMM dd, yyyy HH:mm');
    } catch {
      return 'Unknown';
    }
  };

  const handleApproveSuggestion = async (suggestion: ServiceSuggestion) => {
    if (!canViewSuggestions || isSubmitting) return;

    setIsSubmitting(true);
    
    try {
      const result = await reviewServiceSuggestion(suggestion.id, 'approve', reviewNotes);
      if (result.success) {
        toast.success(`Service suggestion approved for ${suggestion.serviceName}`);
        setReviewNotes('');
        setSelectedSuggestion(null);
        setIsApproveDialogOpen(false);
      } else {
        toast.error(result.error || 'Failed to approve suggestion');
      }
    } catch (error) {
      toast.error('Failed to approve suggestion - please try again');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRejectSuggestion = async (suggestion: ServiceSuggestion) => {
    if (!canViewSuggestions || isSubmitting) return;

    setIsSubmitting(true);
    
    try {
      const result = await reviewServiceSuggestion(suggestion.id, 'reject', reviewNotes);
      if (result.success) {
        toast.success(`Service suggestion rejected for ${suggestion.serviceName}`);
        setReviewNotes('');
        setSelectedSuggestion(null);
        setIsRejectDialogOpen(false);
      } else {
        toast.error(result.error || 'Failed to reject suggestion');
      }
    } catch (error) {
      toast.error('Failed to reject suggestion - please try again');
    } finally {
      setIsSubmitting(false);
    }
  };

  const openApproveDialog = (suggestion: ServiceSuggestion) => {
    setSelectedSuggestion(suggestion);
    setIsApproveDialogOpen(true);
  };

  const openRejectDialog = (suggestion: ServiceSuggestion) => {
    setSelectedSuggestion(suggestion);
    setIsRejectDialogOpen(true);
  };

  if (!canViewSuggestions) {
    return null;
  }

  if (pendingSuggestions.length === 0) {
    return null;
  }

  return (
    <>
      <Card className={className}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-yellow-600" />
            Service Suggestions ({pendingSuggestions.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {pendingSuggestions.slice(0, 3).map((suggestion) => (
              <div key={suggestion.id} className="border rounded-lg p-4 bg-yellow-50">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-medium text-sm">{suggestion.serviceName}</h4>
                      <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
                        <Clock className="h-3 w-3 mr-1" />
                        Pending
                      </Badge>
                    </div>
                    
                    <p className="text-sm text-gray-600 mb-2 line-clamp-2">
                      {suggestion.suggestion}
                    </p>
                    
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <div className="flex items-center gap-1">
                        <User className="h-3 w-3" />
                        {suggestion.suggestedByName || suggestion.suggestedBy}
                      </div>
                      <div>
                        {formatDateTime(suggestion.createdAt)}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 ml-4">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => openApproveDialog(suggestion)}
                      className="bg-green-50 border-green-200 text-green-700 hover:bg-green-100"
                    >
                      <Check className="h-3 w-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => openRejectDialog(suggestion)}
                      className="bg-red-50 border-red-200 text-red-700 hover:bg-red-100"
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
            
            {pendingSuggestions.length > 3 && (
              <div className="text-center">
                <p className="text-sm text-gray-500">
                  +{pendingSuggestions.length - 3} more pending suggestions
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Approve Suggestion Dialog */}
      <Dialog open={isApproveDialogOpen} onOpenChange={setIsApproveDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Approve Service Suggestion</DialogTitle>
            <DialogDescription>
              {selectedSuggestion && `Approve suggestion for ${selectedSuggestion.serviceName}`}
            </DialogDescription>
          </DialogHeader>
          {selectedSuggestion && (
            <div className="space-y-4">
              <div className="bg-green-50 p-3 rounded">
                <div className="text-sm space-y-1">
                  <div><strong>Service:</strong> {selectedSuggestion.serviceName}</div>
                  <div><strong>Suggestion:</strong> {selectedSuggestion.suggestion}</div>
                  <div><strong>Suggested by:</strong> {selectedSuggestion.suggestedByName || selectedSuggestion.suggestedBy}</div>
                  <div><strong>Date:</strong> {formatDateTime(selectedSuggestion.createdAt)}</div>
                </div>
              </div>
              
              <div>
                <Label htmlFor="approveNotes">Review Notes (Optional)</Label>
                <Textarea
                  id="approveNotes"
                  value={reviewNotes}
                  onChange={(e) => setReviewNotes(e.target.value)}
                  placeholder="Add any notes about this approval..."
                  rows={3}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsApproveDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={() => selectedSuggestion && handleApproveSuggestion(selectedSuggestion)} 
              disabled={isSubmitting}
              className="bg-green-600 hover:bg-green-700"
            >
              {isSubmitting ? 'Approving...' : 'Approve Suggestion'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reject Suggestion Dialog */}
      <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Reject Service Suggestion</DialogTitle>
            <DialogDescription>
              {selectedSuggestion && `Reject suggestion for ${selectedSuggestion.serviceName}`}
            </DialogDescription>
          </DialogHeader>
          {selectedSuggestion && (
            <div className="space-y-4">
              <div className="bg-red-50 p-3 rounded">
                <div className="text-sm space-y-1">
                  <div><strong>Service:</strong> {selectedSuggestion.serviceName}</div>
                  <div><strong>Suggestion:</strong> {selectedSuggestion.suggestion}</div>
                  <div><strong>Suggested by:</strong> {selectedSuggestion.suggestedByName || selectedSuggestion.suggestedBy}</div>
                  <div><strong>Date:</strong> {formatDateTime(selectedSuggestion.createdAt)}</div>
                </div>
              </div>
              
              <div>
                <Label htmlFor="rejectNotes">Rejection Reason (Optional)</Label>
                <Textarea
                  id="rejectNotes"
                  value={reviewNotes}
                  onChange={(e) => setReviewNotes(e.target.value)}
                  placeholder="Explain why this suggestion is being rejected..."
                  rows={3}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsRejectDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={() => selectedSuggestion && handleRejectSuggestion(selectedSuggestion)} 
              disabled={isSubmitting}
              className="bg-red-600 hover:bg-red-700"
            >
              {isSubmitting ? 'Rejecting...' : 'Reject Suggestion'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
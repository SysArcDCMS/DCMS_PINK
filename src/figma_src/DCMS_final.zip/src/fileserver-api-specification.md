# FileServer API Specification

## Overview
This document specifies the expected API responses from your FileServer at `http://localhost:9000` to ensure seamless integration with the frontend.

## Base URL
```
http://localhost:9000
```

## Endpoints

### 1. Upload File
**POST** `/api/files`

**Request:**
- Content-Type: `multipart/form-data`
- Form Fields:
  - `file`: File (required)
  - `recordId`: string (required) - ID of the medical record
  - `recordType`: string (required) - Type: "medical_info", "allergy", "medication", "correction_request"
  - `patientId`: string (required)
  - `patientEmail`: string (required)
  - `uploadedBy`: string (required) - User ID who uploaded
  - `uploadedByName`: string (required) - Display name
  - `description`: string (optional)

**Response (Success - 200):**
```json
{
  "file": {
    "id": "file_1234567890_abc123",
    "recordId": "medical_info_1234567890_def456",
    "recordType": "medical_info",
    "patientId": "patient_123",
    "patientEmail": "patient@example.com",
    "fileName": "file_1234567890_abc123_document.pdf",
    "originalFileName": "document.pdf",
    "fileSize": 1024000,
    "fileType": "application/pdf",
    "uploadedBy": "staff_456",
    "uploadedByName": "Dr. Smith",
    "uploadedAt": "2024-01-15T10:30:00.000Z",
    "description": "Medical test results",
    "isActive": true
  }
}
```

**Response (Error - 400/500):**
```json
{
  "error": "File type not allowed"
}
```

### 2. Get Files
**GET** `/api/files`

**Query Parameters:**
- `patientId`: string (optional) - Filter by patient
- `recordId`: string (optional) - Filter by record
- `recordType`: string (optional) - Filter by record type

**Response (Success - 200):**
```json
{
  "files": [
    {
      "id": "file_1234567890_abc123",
      "recordId": "medical_info_1234567890_def456",
      "recordType": "medical_info",
      "patientId": "patient_123",
      "patientEmail": "patient@example.com",
      "fileName": "file_1234567890_abc123_document.pdf",
      "originalFileName": "document.pdf",
      "fileSize": 1024000,
      "fileType": "application/pdf",
      "uploadedBy": "staff_456",
      "uploadedByName": "Dr. Smith",
      "uploadedAt": "2024-01-15T10:30:00.000Z",
      "description": "Medical test results",
      "isActive": true
    }
  ]
}
```

### 3. Download File
**GET** `/api/files/{id}`

**Response (Success - 200):**
- Returns file content with appropriate headers:
  - `Content-Type`: {fileType}
  - `Content-Disposition`: attachment; filename="{originalFileName}"

**Response (Error - 404):**
```json
{
  "error": "File not found"
}
```

### 4. Delete File
**DELETE** `/api/files/{id}`

**Response (Success - 200):**
```json
{
  "message": "File deleted successfully"
}
```

**Response (Error - 404):**
```json
{
  "error": "File not found"
}
```

## File Validation Requirements
- **Allowed file types:**
  - Images: `image/jpeg`, `image/png`, `image/gif`, `image/webp`
  - Documents: `application/pdf`, `application/msword`, `application/vnd.openxmlformats-officedocument.wordprocessingml.document`
  - Text: `text/plain`
- **Maximum file size:** 10MB
- **File naming convention:** `{fileId}_{originalFileName}`

## Important Notes
1. All file responses should NOT include the actual file data in JSON responses (except for download endpoint)
2. Use soft delete (isActive: false) rather than hard delete
3. All timestamps should be in ISO 8601 format
4. File IDs should be unique and prefixed with "file_"
5. Ensure CORS headers are properly set for localhost:3000
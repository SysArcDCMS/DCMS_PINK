# Service-Inventory Mapping System Test Guide

## Testing the Service-Inventory Mapping System

### 1. Basic Access Test
- Navigate to `/dashboard/services/mappings`
- Verify page loads without TypeScript errors
- Check that services table displays correctly
- Verify role-based permissions (Admin/Dentist can edit, Staff view-only)

### 2. Mapping Creation Test
1. Click "Manage Supplies" on any service
2. Add a new inventory item mapping
3. Verify the mapping appears in the list
4. Test quantity editing functionality

### 3. Appointment Completion Test
1. Complete an appointment with services that have mapped inventory items
2. Verify inventory deduction notifications appear
3. Check that inventory quantities are reduced accordingly

### 4. API Endpoint Testing

Test endpoints manually:
- GET `/functions/v1/make-server-c89a26e4/service-inventory-mappings`
- POST `/functions/v1/make-server-c89a26e4/service-inventory-mappings`
- PUT `/functions/v1/make-server-c89a26e4/service-inventory-mappings/{serviceId}/{inventoryItemId}`
- DELETE `/functions/v1/make-server-c89a26e4/service-inventory-mappings/{serviceId}/{inventoryItemId}`

### Expected Behavior
- Automatic inventory deduction when appointments are completed
- Toast notifications showing deducted items
- Warning messages for insufficient inventory
- Proper role-based access control throughout
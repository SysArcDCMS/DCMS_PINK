# Demo Data Setup Guide for Go-Goyagoy Presentation

## 🎭 User Accounts for Demo

### 1. Patient Account
- **Email**: `maria.santos@email.com`
- **Name**: Maria Santos
- **Role**: patient
- **Scenario**: Regular patient with treatment history

### 2. Staff Account  
- **Email**: `nurse.jenny@gogoyagoy.com`
- **Name**: Jenny Rodriguez
- **Role**: staff
- **Scenario**: Dental assistant managing appointments

### 3. Dentist Account
- **Email**: `dr.smith@gogoyagoy.com` 
- **Name**: Dr. Robert Smith
- **Role**: dentist
- **Scenario**: Primary dentist with full access

### 4. Admin Account
- **Email**: `admin@gogoyagoy.com`
- **Name**: Clinic Administrator
- **Role**: admin
- **Scenario**: System administrator

## 📅 Sample Appointments Data

### Completed Appointments (for history)
```json
[
  {
    "patientEmail": "maria.santos@email.com",
    "patientName": "Maria Santos",
    "service": "Dental Filling",
    "dentist": "Dr. Robert Smith",
    "date": "2024-12-01",
    "time": "10:00 AM",
    "status": "completed",
    "teethTreated": ["14", "15"],
    "totalCost": "₱3,500",
    "notes": "Composite filling on upper right molars. Patient reported slight sensitivity."
  },
  {
    "patientEmail": "maria.santos@email.com", 
    "patientName": "Maria Santos",
    "service": "Teeth Cleaning",
    "dentist": "Dr. Robert Smith", 
    "date": "2024-11-15",
    "time": "2:00 PM",
    "status": "completed",
    "teethTreated": ["all"],
    "totalCost": "₱1,500",
    "notes": "Routine prophylaxis. Recommended follow-up in 6 months."
  },
  {
    "patientEmail": "maria.santos@email.com",
    "patientName": "Maria Santos", 
    "service": "Tooth Extraction",
    "dentist": "Dr. Robert Smith",
    "date": "2024-10-20",
    "time": "11:30 AM", 
    "status": "completed",
    "teethTreated": ["18"],
    "totalCost": "₱2,500",
    "notes": "Wisdom tooth extraction. Post-op instructions given."
  }
]
```

### Pending/Upcoming Appointments
```json
[
  {
    "patientEmail": "john.doe@email.com",
    "patientName": "John Doe",
    "service": "Root Canal Treatment", 
    "dentist": "Dr. Robert Smith",
    "date": "2024-12-20",
    "time": "9:00 AM",
    "status": "confirmed", 
    "estimatedCost": "₱8,500"
  },
  {
    "patientEmail": "jane.cruz@email.com",
    "patientName": "Jane Cruz",
    "service": "Dental Crown",
    "dentist": "Dr. Robert Smith", 
    "date": "2024-12-21",
    "time": "2:30 PM",
    "status": "pending",
    "estimatedCost": "₱12,000"
  }
]
```

### Walk-in Patient (for demo)
```json
{
  "firstName": "Carlos",
  "lastName": "Reyes", 
  "email": "carlos.reyes@email.com",
  "phone": "+63 912 345 6789",
  "emergencyReason": "Severe toothache on lower left molar",
  "arrivalTime": "current_time"
}
```

## 🦷 Tooth Chart Data for Maria Santos

### Missing Teeth
```json
["18", "28", "38", "48"]  // All wisdom teeth removed
```

### Treated Teeth with History
```json
[
  {
    "toothFDI": "14",
    "treatments": [
      {
        "id": "tx_001",
        "service_name": "Dental Filling",
        "date": "2024-12-01", 
        "detail": "Composite filling - occlusal surface",
        "appointment_id": "apt_123",
        "completed_by": "Dr. Robert Smith"
      }
    ]
  },
  {
    "toothFDI": "15", 
    "treatments": [
      {
        "id": "tx_002",
        "service_name": "Dental Filling",
        "date": "2024-12-01",
        "detail": "Composite filling - mesial surface", 
        "appointment_id": "apt_123",
        "completed_by": "Dr. Robert Smith"
      }
    ]
  },
  {
    "toothFDI": "26",
    "treatments": [
      {
        "id": "tx_003", 
        "service_name": "Dental Crown",
        "date": "2024-08-15",
        "detail": "Porcelain crown placement",
        "appointment_id": "apt_089", 
        "completed_by": "Dr. Robert Smith"
      }
    ]
  }
]
```

## 💰 Billing Data

### Recent Bills
```json
[
  {
    "billId": "BILL-2024-001",
    "patientEmail": "maria.santos@email.com",
    "patientName": "Maria Santos", 
    "appointmentDate": "2024-12-01",
    "services": [
      {
        "name": "Dental Filling",
        "quantity": 2,
        "unitPrice": "₱1,750", 
        "total": "₱3,500",
        "teethTreated": ["14", "15"]
      }
    ],
    "subtotal": "₱3,500",
    "total": "₱3,500",
    "status": "paid",
    "paymentDate": "2024-12-01"
  },
  {
    "billId": "BILL-2024-002",
    "patientEmail": "john.doe@email.com",
    "patientName": "John Doe",
    "appointmentDate": "2024-11-28", 
    "services": [
      {
        "name": "Teeth Cleaning",
        "quantity": 1,
        "unitPrice": "₱1,500",
        "total": "₱1,500"
      }
    ],
    "subtotal": "₱1,500", 
    "total": "₱1,500",
    "status": "pending"
  }
]
```

## 📦 Inventory Data

### Sample Inventory Items
```json
[
  {
    "id": "inv_001",
    "name": "Composite Resin A3",
    "category": "Restorative Materials",
    "currentStock": 15,
    "minStock": 5, 
    "maxStock": 50,
    "unit": "syringe",
    "costPerUnit": "₱450",
    "supplier": "Dental Supply Co.",
    "lastRestocked": "2024-11-20"
  },
  {
    "id": "inv_002", 
    "name": "Disposable Gloves (L)",
    "category": "PPE",
    "currentStock": 2,
    "minStock": 10,
    "maxStock": 100, 
    "unit": "box",
    "costPerUnit": "₱350",
    "supplier": "MedSafe Supplies",
    "lastRestocked": "2024-11-15",
    "status": "low_stock"
  },
  {
    "id": "inv_003",
    "name": "Lidocaine 2% with Epinephrine",
    "category": "Anesthetics",
    "currentStock": 25,
    "minStock": 10,
    "maxStock": 50,
    "unit": "cartridge", 
    "costPerUnit": "₱85",
    "supplier": "PharmaDent",
    "lastRestocked": "2024-12-01"
  }
]
```

## 🔧 Services Catalog

### Sample Services with Pricing Models
```json
[
  {
    "id": "svc_001",
    "name": "Dental Filling",
    "description": "Composite resin restoration",
    "pricing_model": "Per Tooth",
    "price": "₱1,750",
    "tooth_chart_use": "required",
    "duration": "30-45 minutes",
    "category": "Restorative"
  },
  {
    "id": "svc_002", 
    "name": "Teeth Cleaning",
    "description": "Professional oral prophylaxis",
    "pricing_model": "Per Session",
    "price": "₱1,500", 
    "tooth_chart_use": "optional",
    "duration": "45-60 minutes",
    "category": "Preventive"
  },
  {
    "id": "svc_003",
    "name": "Root Canal Treatment", 
    "description": "Endodontic therapy",
    "pricing_model": "Per Tooth",
    "price": "₱8,500",
    "tooth_chart_use": "required",
    "duration": "90-120 minutes", 
    "category": "Endodontic"
  },
  {
    "id": "svc_004",
    "name": "Dental X-Ray",
    "description": "Periapical radiograph",
    "pricing_model": "Per Film", 
    "price": "₱350",
    "tooth_chart_use": "not needed",
    "duration": "10-15 minutes",
    "category": "Diagnostic"
  }
]
```

## 📱 Demo Scenario Scripts

### Scenario 1: Anonymous Patient Booking
1. **Navigate to**: `/`
2. **Fill booking form**:
   - Name: "Sarah Johnson"
   - Email: "sarah.johnson@email.com" 
   - Phone: "+63 917 123 4567"
   - Service: "Teeth Cleaning"
   - Preferred Date: Tomorrow
3. **Select time slot**: 10:00 AM
4. **Confirm booking**
5. **Show confirmation message**

### Scenario 2: Staff Completing Appointment
1. **Login as**: `nurse.jenny@gogoyagoy.com`
2. **Navigate to**: `/dashboard/appointments`
3. **Find**: Maria Santos appointment
4. **Click**: "Complete Appointment"
5. **Select services**: Dental Filling
6. **Select teeth**: 14, 15 on tooth chart
7. **Add notes**: "Composite filling on upper molars"
8. **Complete appointment**
9. **Show**: Updated tooth chart

### Scenario 3: Patient Viewing History
1. **Login as**: `maria.santos@email.com`
2. **Navigate to**: `/dashboard/service-history`
3. **Show**: Interactive tooth chart
4. **Click**: "View Chart" 
5. **Hover over**: Treated teeth for treatment details
6. **Show**: Treatment history list

### Scenario 4: Admin Managing System
1. **Login as**: `admin@gogoyagoy.com`
2. **Navigate to**: `/dashboard`
3. **Show**: System statistics
4. **Navigate to**: `/dashboard/billing/reports`
5. **Show**: Revenue analytics
6. **Navigate to**: `/dashboard/inventory`
7. **Show**: Stock levels and alerts

## 🎯 Key Demo Points to Highlight

### During Patient Flow:
- "Notice how patients can book without registration"
- "The system automatically suggests available time slots"
- "Confirmation includes all appointment details"

### During Staff Flow:
- "Staff can see all appointments in one view"
- "Tooth chart integration makes billing automatic"
- "Treatment history updates in real-time"

### During Tooth Chart Demo:
- "This uses the international FDI numbering system"
- "Every treatment is permanently recorded"
- "Patients can access their complete dental history"

### During Admin Flow:
- "Real-time analytics for business decisions"
- "Inventory management prevents stockouts"
- "Complete audit trail for all transactions"

## 📋 Pre-Demo Checklist

- [ ] All user accounts created and tested
- [ ] Sample data loaded in correct format
- [ ] Demo appointments ready for completion
- [ ] Tooth chart data properly formatted
- [ ] Billing records populated
- [ ] Inventory items with varied stock levels
- [ ] All demo links bookmarked
- [ ] Backup browser tabs prepared
- [ ] Network connection verified
- [ ] Demo script practiced

## 🔧 Quick Data Reset Commands

If you need to reset demo data during presentation:

1. **Clear appointment**: Delete from appointments list
2. **Reset tooth chart**: Remove treatments from patient record  
3. **Clear billing**: Reset bill status to pending
4. **Refresh inventory**: Update stock levels

Remember: Always have backup data ready in case of demo failures!
// This file is no longer needed in Next.js
// All routing is handled by the Next.js app directory structure
// See /app/layout.tsx for the main application layout
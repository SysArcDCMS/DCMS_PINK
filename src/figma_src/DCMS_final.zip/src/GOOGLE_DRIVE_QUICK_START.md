# Google Drive Integration - Quick Start Guide

## 🚨 You're Here Because of redirect_uri_mismatch Error

Don't worry! This is a common OAuth setup issue. Here's the **fastest way** to fix it:

---

## ✅ **Solution: Use Our Custom Script** (Recommended)

### Step 1: Add Redirect URI to Google Cloud Console

1. **Go to**: https://console.cloud.google.com/apis/credentials
2. **Click** on your OAuth 2.0 Client ID
3. **Add** this URI under "Authorized redirect URIs":
   ```
   http://localhost:3000/oauth/callback
   ```
4. **Click** "SAVE"

### Step 2: Run Our Token Generator

```bash
node scripts/get-google-refresh-token.js
```

### Step 3: Follow the Prompts

The script will:
- ✅ Ask for your Client ID and Client Secret
- ✅ Open your browser for authorization
- ✅ Generate your refresh token
- ✅ Show you the exact code to copy to `.env.local`

### Step 4: Copy to .env.local

The script will output something like:

```env
GOOGLE_DRIVE_CLIENT_ID=123456.apps.googleusercontent.com
GOOGLE_DRIVE_CLIENT_SECRET=abcdefghijk
GOOGLE_DRIVE_REDIRECT_URI=http://localhost:3000/oauth/callback
GOOGLE_DRIVE_REFRESH_TOKEN=1//0a1b2c3d4e5f6g
GOOGLE_DRIVE_ROOT_FOLDER=your_folder_id_here
```

Copy this to your `.env.local` file!

### Step 5: Create Root Folder

1. Go to **Google Drive**: https://drive.google.com
2. Create a new folder named **"DCMS Medical Records"**
3. Right-click → **Get link** → Copy
4. Extract the folder ID from the URL:
   - URL: `https://drive.google.com/drive/folders/1a2b3c4d5e`
   - Folder ID: `1a2b3c4d5e`
5. Add to `.env.local`:
   ```env
   GOOGLE_DRIVE_ROOT_FOLDER=1a2b3c4d5e
   ```

### Step 6: Test It!

```bash
# Start your dev server
npm run dev

# Visit the files page
# http://localhost:3000/dashboard/files
```

Try uploading a file! ✨

---

## 🔧 Alternative: Fix OAuth Playground (If You Prefer)

If you still want to use OAuth Playground:

### Add OAuth Playground URI

1. **Go to**: https://console.cloud.google.com/apis/credentials
2. **Edit** your OAuth 2.0 Client ID
3. **Add** this URI:
   ```
   https://developers.google.com/oauthplayground
   ```
4. **Click** "SAVE"

### Use OAuth Playground

1. **Visit**: https://developers.google.com/oauthplayground/
2. **Click** ⚙️ (gear icon) in top right
3. **Check** "Use your own OAuth credentials"
4. **Enter** your Client ID and Client Secret
5. **In Step 1**, select: `Drive API v3` → `https://www.googleapis.com/auth/drive.file`
6. **Click** "Authorize APIs"
7. **Sign in** and click "Allow"
8. **In Step 2**, click "Exchange authorization code for tokens"
9. **Copy** the refresh token

---

## 📋 Complete Checklist

- [ ] Google Cloud project created
- [ ] Google Drive API enabled
- [ ] OAuth Client ID created
- [ ] Redirect URI added: `http://localhost:3000/oauth/callback`
- [ ] Refresh token obtained (using script or OAuth Playground)
- [ ] Root folder created in Google Drive
- [ ] All variables in `.env.local`
- [ ] Dev server running
- [ ] Test file upload works

---

## 🆘 Still Having Issues?

### Common Problems & Solutions

**Problem**: "Invalid client" error
```
✅ Solution: Double-check your Client ID and Client Secret
```

**Problem**: "Access denied" error
```
✅ Solution: Make sure Google Drive API is enabled
Go to: https://console.cloud.google.com/apis/library/drive.googleapis.com
```

**Problem**: No refresh token received
```
✅ Solution: Revoke previous access and try again
Go to: https://myaccount.google.com/permissions
Find your app and click "Remove Access"
Then run the script again
```

**Problem**: Port 3000 already in use
```
✅ Solution: Stop your Next.js dev server temporarily
Run: pkill -f "next dev"
Run the token script
Then restart your dev server
```

---

## 📚 Full Documentation

For complete setup details:
- **OAuth Setup Guide**: `/docs/google-drive-oauth-setup.md`
- **Integration Guide**: `/docs/google-drive-integration.md`
- **Migration Guide**: `/GOOGLE_DRIVE_MIGRATION.md`
- **File Upload Summary**: `/FILE_UPLOADS_SUMMARY.md`

---

## 🎯 What You're Setting Up

This integration enables:
- ✅ **Cloud storage** for all patient files
- ✅ **Automatic organization** by patient email
- ✅ **Unlimited scalability** via Google Drive
- ✅ **Secure access** with encryption
- ✅ **Easy sharing** with patients/providers
- ✅ **Built-in backups** from Google

Files will be organized like this:
```
DCMS Medical Records/
├── patient1@example.com/
│   ├── medical_info/
│   ├── allergy/
│   ├── medication/
│   └── correction_request/
└── patient2@example.com/
    └── ...
```

---

## 🚀 Quick Commands Reference

```bash
# Get refresh token
node scripts/get-google-refresh-token.js

# Run full setup (after getting token)
node scripts/setup-google-drive.js

# Start dev server
npm run dev

# Test file upload
# Visit: http://localhost:3000/dashboard/files
```

---

## ⏱️ Estimated Time

- **First-time setup**: 10-15 minutes
- **If you have credentials ready**: 3-5 minutes
- **Just fixing the error**: 2 minutes

---

## ✨ Success Indicators

You'll know it's working when:
1. ✅ Script shows "SUCCESS! ✓" message
2. ✅ Refresh token is displayed
3. ✅ `.env.local` file is updated
4. ✅ File upload works in dashboard
5. ✅ Files appear in Google Drive folder

---

**Need help?** Check the troubleshooting guide or review the full documentation!

**Last Updated**: December 2024  
**Difficulty**: ⭐⭐☆☆☆ (Easy with our script!)
